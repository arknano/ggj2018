﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR && PRO
using UnityEditor;
#endif
using UnityEngine;
using System;
using System.Reflection;

namespace InspectorGadgets
{
    /************************************************************************************************************************/

    /// <summary>[Pro-Only]
    /// Causes an enum or string field to be drawn in the inspector as a series of toggle buttons rather than the usual
    /// dropdown list or text field.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class ToolbarAttribute : PropertyAttribute
    {
        /// <summary>
        /// The labels for each button in the toolbar. Enums will use their own names.
        /// </summary>
        public readonly GUIContent[] Labels;

        /// <summary>
        /// Constructs a new <see cref="ToolbarAttribute"/>.
        /// You must specify the <see cref="Labels"/> unless the attributed field is an enum.
        /// </summary>
        public ToolbarAttribute() { }

        /// <summary>
        /// Constructs a new <see cref="ToolbarAttribute"/> using the specified labels (not required for enums).
        /// </summary>
        public ToolbarAttribute(params GUIContent[] labels)
        {
            Labels = labels;
        }

        /// <summary>
        /// Constructs a new <see cref="ToolbarAttribute"/> using the specified labels (not required for enums).
        /// </summary>
        public ToolbarAttribute(params string[] labels)
        {
            Labels = new GUIContent[labels.Length];
            for (int i = 0; i < labels.Length; i++)
            {
                Labels[i] = new GUIContent(labels[i]);
            }
        }
    }

    /************************************************************************************************************************/

#if UNITY_EDITOR && PRO
    [CustomPropertyDrawer(typeof(ToolbarAttribute))]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class ToolbarDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        private static readonly GUIStyle
            LeftButtonStyle,
            MidButtonStyle,
            RightButtonStyle;

        static ToolbarDrawer()
        {
            LeftButtonStyle = new GUIStyle(EditorStyles.miniButtonLeft);
            MidButtonStyle = new GUIStyle(EditorStyles.miniButtonMid);
            RightButtonStyle = new GUIStyle(EditorStyles.miniButtonRight);

            LeftButtonStyle.padding = MidButtonStyle.padding = RightButtonStyle.padding = new RectOffset(4, 4, 2, 2);
        }

        /************************************************************************************************************************/

        private static readonly int
            DragControlHint = "ToolbarDragControl".GetHashCode();

        private Type _FieldType;
        private bool _IsFlags;
        private int _Count;
        private GUIContent[] _Labels;
        private long[] _Values;
        private float[] _Widths;
        private float _TotalWidth, _FieldWidth, _ScrollPosition;

        /************************************************************************************************************************/

        private void ClampScrollPosition()
        {
            _ScrollPosition = Mathf.Clamp(_ScrollPosition, 0, _TotalWidth - _FieldWidth);
        }

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (Event.current.type == EventType.Layout)
                return;

            Initialise(property, label);

            DoToolbar(position, property, label);

            // Handle scroll events if you are too wide.
            if (Event.current.type == EventType.ScrollWheel &&
                _TotalWidth > _FieldWidth &&
                position.Contains(Event.current.mousePosition))
            {
                _ScrollPosition += (Event.current.delta.y + Event.current.delta.x) * 10;
                ClampScrollPosition();
                Event.current.Use();
            }
        }

        /************************************************************************************************************************/

        private void Initialise(SerializedProperty property, GUIContent label)
        {
            // Already initialised.
            if (_Labels != null)
                return;

            DetermineFieldType();

            if (_FieldType == typeof(string))// String.
            {
                _Labels = (attribute as ToolbarAttribute).Labels;

                if (_Labels == null)
                {
                    Debug.LogWarning("The [Toolbar] attribute applied to " + fieldInfo.DeclaringType.FullName + "." + fieldInfo.Name +
                        " must specify the labels you with to display.");
                    _Labels = new GUIContent[0];
                    return;
                }

                _Count = _Labels.Length;
            }
            else if (_FieldType.IsEnum)// Enum.
            {
                _IsFlags = _FieldType.IsDefined(typeof(FlagsAttribute), true);

                Array enumValues = Enum.GetValues(_FieldType);

                string[] displayNames = property.enumDisplayNames;
                string[] trueNames = property.enumNames;

                _Labels = new GUIContent[enumValues.Length];
                _Values = new long[enumValues.Length];

                _Count = 0;

                for (int i = 0; i < enumValues.Length; i++)
                {
                    var value = Convert.ToInt64(enumValues.GetValue(i));

                    // Skip zero values in flags enums.
                    if (_IsFlags && value == 0)
                        continue;

                    _Labels[_Count] = new GUIContent(displayNames[i], trueNames[i]);

                    _Values[_Count] = value;

                    _Count++;
                }
            }
            else// Invalid field type.
            {
                _Labels = new GUIContent[0];
                Debug.LogWarning("The [Toolbar] attribute is only valid on enum and string fields.");
                return;
            }

            // Initialise the button widths.
            _Widths = new float[_Count];

            _TotalWidth = 0;

            for (int i = 0; i < _Count; i++)
            {
                float width = MidButtonStyle.CalcSize(_Labels[i]).x;
                _Widths[i] = width;
                _TotalWidth += width;
            }
        }

        /************************************************************************************************************************/

        private void DetermineFieldType()
        {
            _FieldType = fieldInfo.FieldType;

            while (_FieldType.IsGenericType)
            {
                var genericArguments = _FieldType.GetGenericArguments();
                if (genericArguments.Length == 1)
                    _FieldType = genericArguments[0];
                else
                    break;
            }

            while (_FieldType.IsArray)
            {
                _FieldType = _FieldType.GetElementType();
            }
        }

        /************************************************************************************************************************/

        private void DoToolbar(Rect position, SerializedProperty property, GUIContent label)
        {
            if (_Labels == null || _Labels.Length == 0)
            {
                EditorGUI.PropertyField(position, property, label);
                return;
            }

            _FieldWidth = position.width - EditorGUIUtility.labelWidth;

            float right = position.xMax;

            position.width = EditorGUIUtility.labelWidth;

            // Drag.

            float spareSpace;
            if (_TotalWidth > _FieldWidth)
            {
                int controlID = GUIUtility.GetControlID(DragControlHint, FocusType.Passive, position);
                DragNumberValue(position, controlID, ref _ScrollPosition);
                ClampScrollPosition();

                _FieldWidth -= 2;
                //right -= 1;
                spareSpace = 0;
            }
            else spareSpace = (_FieldWidth - _TotalWidth) / _Count;

            // Label.

            GUI.Label(position, label);

            if (_Labels.Length == 0)
                return;

            // Buttons.

            position.x += position.width;
            position.xMax = right;
            GUI.BeginGroup(position);

            position.x = -_ScrollPosition;
            position.y = 0;

            if (_FieldType.IsEnum)
                DoEnumButtons(position, property, spareSpace);
            else
                DoStringButtons(position, property, spareSpace);

            GUI.EndGroup();
        }

        /************************************************************************************************************************/

        private void DoEnumButtons(Rect position, SerializedProperty property, float spareSpace)
        {
            float right = position.width;

            long propertyValue = property.longValue;

            for (int i = 0; i < _Count; i++)
            {
                var value = _Values[i];
                position.width = _Widths[i] + spareSpace;

                // Make sure the last button goes all the way to the end.
                if (i == _Count - 1 && position.xMax < right)
                    position.xMax = right;

                if (_IsFlags)// Flags Enum.
                {
                    bool wasPressed = (property.intValue & value) == value;
                    bool isPressed = GUI.Toggle(position, wasPressed, _Labels[i], GetStyle(i));

                    if (isPressed != wasPressed)
                    {
                        if (isPressed)
                            propertyValue |= value;
                        else
                            propertyValue &= ~value;
                    }
                }
                else// Standard Enum.
                {
                    bool pressed = propertyValue == value;

                    pressed = GUI.Toggle(position, pressed, _Labels[i], GetStyle(i));

                    if (pressed) propertyValue = value;
                }

                position.x += position.width;
            }

            if (property.longValue != propertyValue)
                property.longValue = propertyValue;
        }

        /************************************************************************************************************************/

        private void DoStringButtons(Rect position, SerializedProperty property, float spareSpace)
        {
            float right = position.width;

            string propertyValue = property.stringValue;

            for (int i = 0; i < _Count; i++)
            {
                var label = _Labels[i];
                position.width = _Widths[i] + spareSpace;

                // Make sure the last button goes all the way to the end.
                if (i == _Count - 1 && position.xMax < right)
                    position.xMax = right;

                bool pressed = propertyValue == label.text;

                pressed = GUI.Toggle(position, pressed, label, GetStyle(i));

                if (pressed) propertyValue = label.text;

                position.x += position.width;
            }

            if (property.stringValue != propertyValue)
                property.stringValue = propertyValue;
        }

        /************************************************************************************************************************/

        private static float _DragStartValue;

        private static void DragNumberValue(Rect position, int id, ref float value)
        {
            Event current = Event.current;
            switch (current.GetTypeForControl(id))
            {
                case EventType.MouseDown:
                    if (current.button == 0 && position.Contains(current.mousePosition))
                    {
                        EditorGUIUtility.editingTextField = false;
                        GUIUtility.hotControl = id;
                        GUIUtility.keyboardControl = id;
                        Undo.IncrementCurrentGroup();
                        current.Use();
                        _DragStartValue = value;
                        EditorGUIUtility.SetWantsMouseJumping(1);
                    }
                    break;
                case EventType.MouseUp:
                    if (GUIUtility.hotControl == id)// && EditorGUI.s_DragCandidateState != 0)
                    {
                        GUIUtility.hotControl = 0;
                        current.Use();
                        EditorGUIUtility.SetWantsMouseJumping(0);
                    }
                    break;
                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == id)
                    {
                        value -= HandleUtility.niceMouseDelta;
                        GUI.changed = true;
                        current.Use();
                    }
                    break;
                case EventType.KeyDown:
                    if (GUIUtility.hotControl == id && current.keyCode == KeyCode.Escape)
                    {
                        value = _DragStartValue;
                        GUI.changed = true;
                        GUIUtility.hotControl = 0;
                        current.Use();
                    }
                    break;
                case EventType.Repaint:
                    EditorGUIUtility.AddCursorRect(position, MouseCursor.SlideArrow);
                    break;
            }
        }

        /************************************************************************************************************************/

        private GUIStyle GetStyle(int index)
        {
            if (index <= 0)
                return LeftButtonStyle;

            if (index >= _Count - 1)
                return RightButtonStyle;

            return MidButtonStyle;
        }

        /************************************************************************************************************************/
    }
#endif
}