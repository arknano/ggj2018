﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Reflection;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// <see cref="Editor{T}"/> uses this attribute to add a label at the bottom of the default inspector to display the value of the marked property.
    /// </summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Method | AttributeTargets.Property)]
    public sealed class LabelAttribute : InspectableAttribute
    {
        /************************************************************************************************************************/

        /// <summary>The label to use as a prefix before the value. If not set, it will use the name of the attributed member.</summary>
        public string Label { get; set; }

        /// <summary>If true, the label will be hidden when the value is null.</summary>
        public bool HideWhenNull { get; set; }

        /// <summary>If true, the inspector will be constantly repainted while this label is shown to keep it updated.</summary>
        public bool ConstantlyRepaint { get; set; }

        /// <summary>If true, the <see cref="Label"/> or attributed member name will be drawn on one line with the actual value drawn below it and able to take as many lines as you want.</summary>
        public bool Multiline { get; set; }

        /************************************************************************************************************************/
#if UNITY_EDITOR && PRO
        /************************************************************************************************************************/

        private Color? _Color;
        private Func<object, object> _Getter;
        private bool _IsStatic;
        private MemberInfo _Member;

        /************************************************************************************************************************/

        /// <summary>Initialise this label with a field, property, or method.</summary>
        protected override void Initialise(MemberInfo member)
        {
            _Member = member;

            if (member is FieldInfo field)
            {
                Initialise(field.GetValue, field.IsStatic, field.Name, field);

                return;
            }

            if (member is PropertyInfo property)
            {
                MethodInfo getter = property.GetGetMethod(true);

                if (getter != null)
                    Initialise(obj => getter.Invoke(obj, null), getter.IsStatic, property.Name, property);
                else
                    LogInvalidMember(member, "it has no getter");

                return;
            }

            if (member is MethodInfo method)
            {
                if (method.GetParameters().Length == 0)
                    Initialise(obj => method.Invoke(obj, null), method.IsStatic, method.Name, method);
                else
                    LogInvalidMember(member, "it has parameters");

                return;
            }
        }

        /************************************************************************************************************************/

        private void Initialise(Func<object, object> getter, bool isStatic, string name, ICustomAttributeProvider attributeProvider)
        {
            _Getter = getter;
            _IsStatic = isStatic;

            if (Label == null)
                Label = InspectorGadgetsUtils.ConvertFieldNameToFriendly(name, true);

            var attributes = attributeProvider.GetCustomAttributes(typeof(ColorAttribute), true);
            if (attributes != null && attributes.Length > 0)
                _Color = (attributes[0] as ColorAttribute).Color;
        }

        /************************************************************************************************************************/

        /// <summary>Draw this label using <see cref="GUILayout"/>.</summary>
        protected override void OnGUI(UnityEngine.Object[] targets, ref bool repaint)
        {
            string label;
            Exception exception;

            try
            {
                object value = _Getter(_IsStatic ? null : targets[0]);

                if (HideWhenNull && value == null)
                    return;

                label = value != null ? value.ToString() : "null";
                exception = null;
            }
            catch (Exception ex)
            {
                label = ex.GetBaseException().GetType().Name;
                exception = ex;
            }

            Color oldColor = GUI.color;
            if (_Color != null) GUI.color = _Color.Value;
            if (Multiline)
            {
                GUILayout.BeginHorizontal();
                {
                    GUILayout.Label(Label);
                    DoLogButton(targets, label, exception);
                }
                GUILayout.EndHorizontal();

                GUILayout.Label(label, UnityEditor.EditorStyles.wordWrappedLabel);
            }
            else
            {
                GUILayout.BeginHorizontal();
                {
                    UnityEditor.EditorGUILayout.LabelField(Label, label);
                    DoLogButton(targets, label, exception);
                }
                GUILayout.EndHorizontal();
            }
            GUI.color = oldColor;

            if (ConstantlyRepaint)
                repaint = true;
        }

        /************************************************************************************************************************/

        private static readonly GUILayoutOption[] DontExpandWidth = { GUILayout.ExpandWidth(false) };

        private void DoLogButton(UnityEngine.Object[] targets, string label, Exception exception)
        {
            if (GUILayout.Button("Log", UnityEditor.EditorStyles.miniButton, DontExpandWidth))
            {
                if (exception == null)
                {
                    Debug.Log(_Member.GetNameCS() + ": " + label, targets[0]);
                }
                else
                {
                    Debug.LogException(exception, targets[0]);
                }
            }
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}