﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Reflection;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// <see cref="Editor{T}"/> uses this attribute to add a button at the bottom of the default inspector to run the marked method.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class ButtonAttribute : InspectableAttribute
    {
        /************************************************************************************************************************/

        /// <summary>The label to display on the button. If not set, it will use the name of the method.</summary>
        public GUIContent Label { get; set; }

        /// <summary>If true, clicking the button will automatically call <see cref="UnityEditor.EditorUtility.SetDirty"/> after invoking the method.</summary>
        public bool SetDirty { get; set; }

        /************************************************************************************************************************/
#if UNITY_EDITOR && PRO
        /************************************************************************************************************************/

        private MethodInfo _Method;

        /// <summary>Initialise this button with a method.</summary>
        protected override void Initialise(MemberInfo member)
        {
            _Method = member as MethodInfo;

            if (Label == null)
            {
                Label = new GUIContent(
                    InspectorGadgetsUtils.ConvertCamelCaseToFriendly(_Method.Name),
                    "Calls " + _Method.GetNameCS());
            }
        }

        /************************************************************************************************************************/

        /// <summary>Draw this button using <see cref="GUILayout"/>.</summary>
        protected override void OnGUI(UnityEngine.Object[] targets, ref bool repaint)
        {
            if (GUILayout.Button(Label, UnityEditor.EditorStyles.miniButton))
            {
                if (_Method.IsStatic)// Static Method.
                {
                    object result = _Method.Invoke(null, null);

                    if (SetDirty)
                        foreach (var target in targets)
                            UnityEditor.EditorUtility.SetDirty(target);

                    if (_Method.ReturnType != typeof(void))
                        Debug.Log(Label.text + ": " + result);
                }
                else// Instance Method.
                {
                    foreach (var target in targets)
                    {
                        object result = _Method.Invoke(target, null);

                        if (SetDirty)
                            UnityEditor.EditorUtility.SetDirty(target);

                        if (_Method.ReturnType != typeof(void))
                            Debug.Log(Label.text + ": " + result, target);
                    }
                }
            }
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}