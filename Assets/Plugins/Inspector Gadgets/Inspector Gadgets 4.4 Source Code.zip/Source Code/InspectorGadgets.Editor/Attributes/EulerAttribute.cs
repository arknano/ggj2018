﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
#endif
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Causes the attributed <see cref="Quaternion"/> field to be drawn as Euler Angles.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class EulerAttribute : PropertyAttribute { }

    /************************************************************************************************************************/

#if UNITY_EDITOR && PRO
    [CustomPropertyDrawer(typeof(EulerAttribute))]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class EulerDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        private sealed class Data
        {
            public Vector3 eulerAngles, oldEulerAngles;
        }

        private static readonly Dictionary<string, Data>
            CachedData = new Dictionary<string, Data>();

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (property.propertyType != SerializedPropertyType.Quaternion)
            {
                EditorGUI.PropertyField(position, property, label);
                Debug.LogError("Invalid [Euler] Attribute: " + InspectorGadgetsUtils.TryGetFieldInfo(property).GetNameCS() + " is not a Quaternion.");
                return;
            }

            if (!CachedData.TryGetValue(property.propertyPath, out Data data))
            {
                data = new Data();
                data.eulerAngles = data.oldEulerAngles = property.quaternionValue.eulerAngles;

                CachedData.Add(property.propertyPath, data);
            }

            bool wideMode = EditorGUIUtility.wideMode;
            bool showMixedValue = EditorGUI.showMixedValue;

            EditorGUIUtility.wideMode = true;
            EditorGUI.showMixedValue = property.hasMultipleDifferentValues;

            EditorGUI.BeginProperty(position, label, property);

            if (EditorGUI.showMixedValue)
            {
                data.eulerAngles = data.oldEulerAngles = Vector3.zero;
            }
            else
            {
                Vector3 euler = property.quaternionValue.eulerAngles;
                if (data.oldEulerAngles != euler)
                {
                    data.eulerAngles = euler;
                }
            }

            EditorGUI.BeginChangeCheck();
            data.eulerAngles = EditorGUI.Vector3Field(position, label, data.eulerAngles);
            if (EditorGUI.EndChangeCheck())
            {
                var quaternion = Quaternion.Euler(data.eulerAngles);
                property.quaternionValue = quaternion;
                data.oldEulerAngles = quaternion.eulerAngles;
            }

            EditorGUI.EndProperty();

            EditorGUI.showMixedValue = showMixedValue;
            EditorGUIUtility.wideMode = wideMode;
        }

        /************************************************************************************************************************/
    }
#endif
}