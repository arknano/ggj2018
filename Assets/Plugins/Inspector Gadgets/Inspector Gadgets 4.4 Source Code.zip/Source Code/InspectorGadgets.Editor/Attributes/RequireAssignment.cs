﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Reflection;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// When the attributed member is drawn in the inspector, it will be highlighted in red when it has the default value.
    /// </summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public sealed class RequireAssignmentAttribute : PropertyAttribute
    {
        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/

        private SerializedProperty _SerializedProperty;
        private FieldInfo _Field;
        private PropertyInfo _Property;
        private Type _Type;
        private bool _IsReferenceOrNullable;
        private object _DefaultValue;

        /************************************************************************************************************************/

        internal bool IsInitialised
        {
            get
            {
                return _SerializedProperty != null || _Field != null || _Property != null;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Initialises this attribute to check the value of the specified 'field'.
        /// </summary>
        public void Initialise(SerializedProperty property)
        {
            _SerializedProperty = property;
            InspectorGadgetsUtils.TryGetFieldInfo(property, out var propertyType);
            Initialise(propertyType);
        }

        /// <summary>
        /// Initialises this attribute to check the value of the specified 'field'.
        /// </summary>
        public void Initialise(FieldInfo field)
        {
            _Field = field;
            Initialise(field.FieldType);
        }

        /// <summary>
        /// Initialises this attribute to check the value of the specified 'property'.
        /// </summary>
        public void Initialise(PropertyInfo property)
        {
            _Property = property;
            Initialise(property.PropertyType);
        }

        /************************************************************************************************************************/

        private void Initialise(Type type)
        {
            _Type = type;

            if (!type.IsValueType || Nullable.GetUnderlyingType(type) != null)
                _IsReferenceOrNullable = true;
            else
                _DefaultValue = Activator.CreateInstance(type);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if the attributed member on the specified 'obj' still has its default value.
        /// </summary>
        public bool IsDefaultValue(object obj)
        {
            object value;
            if (_SerializedProperty != null)
                value = InspectorGadgetsUtils.GetValue(_SerializedProperty, obj);
            else if (_Field != null)
                value = _Field.GetValue(obj);
            else if (_Property != null)
                value = _Property.GetValue(obj, null);
            else
                return false;

            if (value == null)
                return true;

            if (_Type == typeof(string))
                return value.Equals("");

            // Non-null reference or nullable is not default.
            if (_IsReferenceOrNullable)
            {
                return
                    (obj as UnityEngine.Object) != null &&
                    value is UnityEngine.Object &&
                    (value as UnityEngine.Object) == null;
            }

            // Otherwise it is a value type, so we need to compare it to the default value.
            return value.Equals(_DefaultValue);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns the full name of the attributed field or property.
        /// </summary>
        public override string ToString()
        {
            if (_Field != null)
                return _Field.DeclaringType.FullName + "." + _Field.Name;
            else if (_Property != null)
                return _Property.DeclaringType.FullName + "." + _Property.Name;
            else
                return base.ToString();
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
#if UNITY_EDITOR
    /************************************************************************************************************************/

    [CustomPropertyDrawer(typeof(RequireAssignmentAttribute))]
    internal sealed class RequireAssignmentDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        private RequireAssignmentAttribute _Attribute;

        /************************************************************************************************************************/

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUI.GetPropertyHeight(property, label);
        }

        /************************************************************************************************************************/

        private static readonly Color
            ErrorFieldColor = new Color(1, 0.65f, 0.65f);

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var color = GUI.color;

            if (Event.current.type == EventType.Repaint)
            {
                Initialise(property);

                if (_Attribute != null && _Attribute.IsInitialised)
                {
                    var targets = property.serializedObject.targetObjects;
                    foreach (var target in targets)
                    {
                        if (_Attribute.IsDefaultValue(target))
                        {
                            GUI.color = ErrorFieldColor;
                            break;
                        }
                    }
                }
            }

            EditorGUI.PropertyField(position, property, label, property.isExpanded);

            GUI.color = color;
        }

        /************************************************************************************************************************/

        private void Initialise(SerializedProperty property)
        {
            if (_Attribute != null)
                return;

            _Attribute = attribute as RequireAssignmentAttribute;
            _Attribute.Initialise(property);
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
#endif
    /************************************************************************************************************************/
}