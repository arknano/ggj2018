﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Provides labels for the elements of a collection field to use instead of just calling them Element X.
    /// </summary>
    public sealed class LabelledCollectionAttribute : PropertyAttribute
    {
        /************************************************************************************************************************/

        private Func<int, string> _GetLabel;

        /// <summary>Get the label to use for the element at the specified 'index' in the collection.</summary>
        public string GetLabel(int index)
        {
            if (_GetLabel != null)
                return _GetLabel(index);
            else
                return null;
        }

        /************************************************************************************************************************/

        /// <summary>Uses the specified 'labels' for the collection elements.</summary>
        public LabelledCollectionAttribute(params string[] labels)
        {
            _GetLabel = (int index) => labels[index % labels.Length];
        }

        /************************************************************************************************************************/

        /// <summary>Uses the value names of the specified 'enumType' for the collection elements.</summary>
        public LabelledCollectionAttribute(Type enumType)
        {
            var names = Enum.GetNames(enumType);
            _GetLabel = (int index) =>
            {
                if (index >= 0 && index < names.Length)
                    return names[index];
                else
                    return index.ToString();
            };
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Uses the member with the specified name to determine the labels of the collection elements.
        /// <para></para>
        /// If the member is a collection field, the values in that collection will be used as the element labels.
        /// <para></para>
        /// If the member is a method with a single int parameter and a non-void return type, it will be called with
        /// each element index to determine the label.
        /// </summary>
        public LabelledCollectionAttribute(string memberName)
        {
#if UNITY_EDITOR
            _MemberName = memberName;
#endif
        }

        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/

        private static readonly Type[] MethodParameterTypes = { typeof(int) };

        private string _MemberName;

        internal void Initialise(FieldInfo attributedField, UnityEditor.SerializedProperty property)
        {
            if (_MemberName == null)
                return;

            var memberName = _MemberName;
            _MemberName = null;

            const BindingFlags AllBindings = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;

            var field = attributedField.DeclaringType.GetField(memberName, AllBindings);
            if (field != null)
            {
                if (field.FieldType.IsArray)// Array Field.
                {
                    var target = InspectorGadgetsUtils.GetValue(property, 1);

                    _GetLabel = (int index) =>
                    {
                        if (field.GetValue(target) is Array array && index >= 0 && index < array.Length)
                        {
                            return array.GetValue(index)?.ToString();
                        }
                        else
                        {
                            return index.ToString();
                        }
                    };
                }
                else if (typeof(IList).IsAssignableFrom(field.FieldType))// List Field.
                {
                    var target = InspectorGadgetsUtils.GetValue(property, 1);

                    _GetLabel = (int index) =>
                    {
                        if (field.GetValue(target) is IList list && index >= 0 && index < list.Count)
                        {
                            return list[index]?.ToString();
                        }
                        else
                        {
                            return index.ToString();
                        }
                    };
                }

                return;
            }

            var method = attributedField.DeclaringType.GetMethod(memberName, AllBindings, null, MethodParameterTypes, null);
            if (method != null)
            {
                if (method.ReturnType != typeof(void))
                {
                    var target = InspectorGadgetsUtils.GetValue(property, 1);
                    var parameters = new object[1];

                    _GetLabel = (int index) =>
                    {
                        parameters[0] = index;
                        object name = method.Invoke(target, parameters);
                        if (name != null)
                            return name.ToString();
                        else
                            return null;
                    };
                }

                return;
            }
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
#if UNITY_EDITOR
    /************************************************************************************************************************/

    [UnityEditor.CustomPropertyDrawer(typeof(LabelledCollectionAttribute))]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class NamedCollectionDrawer : UnityEditor.PropertyDrawer
    {
        /************************************************************************************************************************/

        private readonly Dictionary<string, int>
            PropertyIndices = new Dictionary<string, int>();

        /************************************************************************************************************************/

        public override float GetPropertyHeight(UnityEditor.SerializedProperty property, GUIContent label)
        {
            return UnityEditor.EditorGUI.GetPropertyHeight(property, label);
        }

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, UnityEditor.SerializedProperty property, GUIContent label)
        {
            if (!string.IsNullOrEmpty(label.text) || !string.IsNullOrEmpty(label.tooltip))
            {
                string path = property.propertyPath;

                if (!PropertyIndices.TryGetValue(path, out int index))
                {
                    index = path.LastIndexOf('[');
                    if (index >= 0)
                    {
                        index++;
                        int close = path.IndexOf(']', index);
                        if (index >= 0)
                        {
                            string textIndex = path.Substring(index, close - index);
                            if (!int.TryParse(textIndex, out index))
                                index = -1;
                        }
                    }

                    PropertyIndices.Add(path, index);
                }

                if (index >= 0)
                {
                    var attribute = this.attribute as LabelledCollectionAttribute;
                    attribute.Initialise(fieldInfo, property);

                    string name = attribute.GetLabel(index);

                    if (!string.IsNullOrEmpty(name))
                        label = new GUIContent(name, label.text + ": " + name);
                }
            }

            UnityEditor.EditorGUI.PropertyField(position, property, label, property.isExpanded);
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
#endif
    /************************************************************************************************************************/
}