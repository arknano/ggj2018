﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// <see cref="Editor{T}"/> uses these attributes to add extra elements to the inspector.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public abstract class InspectableAttribute : Attribute
    {
        /************************************************************************************************************************/

        /// <summary>Determines when this attribute should be active.</summary>
        public EditorState When { get; set; }

        /************************************************************************************************************************/
#if UNITY_EDITOR && PRO
        /************************************************************************************************************************/

        private static readonly Dictionary<Type, List<InspectableAttribute>>
            AllInspectables = new Dictionary<Type, List<InspectableAttribute>>();

        /************************************************************************************************************************/

        internal static List<InspectableAttribute> Gather(Type targetType)
        {
            if (!AllInspectables.TryGetValue(targetType, out List<InspectableAttribute> inspectables))
            {
                inspectables = new List<InspectableAttribute>();

                List<FieldInfo> fields = new List<FieldInfo>();
                List<MethodInfo> methods = new List<MethodInfo>();
                List<PropertyInfo> properties = new List<PropertyInfo>();

                const BindingFlags Bindings = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;

                int index = 0;

                // Fields.
                InspectorGadgetsUtils.GetAttributedFields(targetType, Bindings, inspectables, fields);
                for (int i = 0; i < fields.Count; i++)
                {
                    inspectables[index++].Initialise(fields[i]);
                }

                // Properties.
                InspectorGadgetsUtils.GetAttributedProperties(targetType, Bindings, inspectables, properties);
                for (int i = 0; i < properties.Count; i++)
                {
                    inspectables[index++].Initialise(properties[i]);
                }

                // Methods.
                InspectorGadgetsUtils.GetAttributedMethods(targetType, Bindings, inspectables, methods);
                for (int i = 0; i < methods.Count; i++)
                {
                    inspectables[index++].Initialise(methods[i]);
                }

                AllInspectables.Add(targetType, inspectables);
            }

            return inspectables;
        }

        /************************************************************************************************************************/

        /// <summary>Initialise this inspectable with a member.</summary>
        protected virtual void Initialise(MemberInfo member) { }

        /************************************************************************************************************************/

        /// <summary>Logs a warning that the specified 'member' can't have this kind of attribute for the given 'reason'.</summary>
        protected void LogInvalidMember(MemberInfo member, string reason)
        {
            var text = new StringBuilder();
            text.Append("The member: ");
            text.Append(member.DeclaringType.FullName);
            text.Append('.');
            text.Append(member.Name);
            text.Append(" cannot have a [");
            text.Append(GetType().FullName);
            text.Append("] attribute because ");
            text.Append(reason);
            text.Append('.');
            Debug.LogWarning(text.ToString());
        }

        /************************************************************************************************************************/

        internal static void DoAll(List<InspectableAttribute> inspectables, UnityEngine.Object[] targets, out bool repaint)
        {
            repaint = false;

            for (int i = 0; i < inspectables.Count; i++)
            {
                InspectableAttribute inspectable = inspectables[i];
                if (inspectable.When.IsNow())
                    inspectable.OnGUI(targets, ref repaint);
            }
        }

        /// <summary>Draw this inspectable using <see cref="GUILayout"/>.</summary>
        protected abstract void OnGUI(UnityEngine.Object[] targets, ref bool repaint);

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}