﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System.Reflection;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Causes the attributed field to be drawn in a specific color.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class ColorAttribute : PropertyAttribute
    {
        /// <summary>The color to use.</summary>
        public readonly Color Color;

        /// <summary>Initialises the color with the specified red, green, and blue values.</summary>
        public ColorAttribute(float r, float g, float b)
        {
            Color = new Color(r, g, b);
        }
    }

    /************************************************************************************************************************/

#if UNITY_EDITOR && PRO
    [UnityEditor.CustomPropertyDrawer(typeof(ColorAttribute))]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class ColorDrawer : UnityEditor.PropertyDrawer
    {
        /************************************************************************************************************************/

        public override void OnGUI(Rect position, UnityEditor.SerializedProperty property, GUIContent label)
        {
            Color oldColor = GUI.color;
            GUI.color = (attribute as ColorAttribute).Color;
            {
                UnityEditor.EditorGUI.PropertyField(position, property, property.isExpanded);
            }
            GUI.color = oldColor;
        }

        /************************************************************************************************************************/

        public override float GetPropertyHeight(UnityEditor.SerializedProperty property, GUIContent label)
        {
            return UnityEditor.EditorGUI.GetPropertyHeight(property, label, true);
        }

        /************************************************************************************************************************/
    }
#endif
}