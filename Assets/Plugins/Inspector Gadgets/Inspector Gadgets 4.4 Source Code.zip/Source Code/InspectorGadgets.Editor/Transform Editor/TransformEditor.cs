﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Reflection;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace InspectorGadgets
{
    [CustomEditor(typeof(Transform))]
#if PRO
    [CanEditMultipleObjects]
#endif
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class TransformEditor : Editor
    {
        /************************************************************************************************************************/
        #region Fields
        /************************************************************************************************************************/

        public readonly PositionDrawer Position;
        public readonly RotationDrawer Rotation;
        public readonly ScaleDrawer Scale;

        public Transform[] Targets { get; private set; }
        public bool CurrentIsLocalMode { get; private set; }
        public bool CurrentFreezeChildTransforms { get; private set; }
        public bool UseUniformScale { get; internal set; }

        /************************************************************************************************************************/

        public static readonly AutoPrefs.EditorBool
            DefaultToUniformScale = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(DefaultToUniformScale), true),
            IsLocalMode = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(IsLocalMode), true),
            OverrideTransformGizmos = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(OverrideTransformGizmos), true),
            FreezeChildTransforms = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(FreezeChildTransforms), false),
            DrawAllGizmos = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(DrawAllGizmos), false);

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Inspector
        /************************************************************************************************************************/

        public TransformEditor()
        {
            Position = new PositionDrawer(this);
            Rotation = new RotationDrawer(this);
            Scale = new ScaleDrawer(this);
        }

        /************************************************************************************************************************/

        private void OnEnable()
        {
            if (Targets == null || Targets.Length != targets.Length)
                Targets = new Transform[targets.Length];
            for (int i = 0; i < Targets.Length; i++)
                Targets[i] = targets[i] as Transform;

            Position.OnEnable(serializedObject);
            Rotation.OnEnable(serializedObject);
            Scale.OnEnable(serializedObject);

            CurrentIsLocalMode = IsLocalMode;
            CurrentFreezeChildTransforms = FreezeChildTransforms;
            UseUniformScale = DefaultToUniformScale;
        }

        private void OnDisable()
        {
            Tools.hidden = false;

            IsLocalMode.Value = CurrentIsLocalMode;
            FreezeChildTransforms.Value = CurrentFreezeChildTransforms;

            Position.OnDisable();
            Rotation.OnDisable();
            Scale.OnDisable();
        }

        /************************************************************************************************************************/

        public override void OnInspectorGUI()
        {
            if (Event.current.type == EventType.Layout)
            {
                Rotation.CheckIfArbitrarilyRotated();
                if (!CurrentIsLocalMode && Rotation.IsArbitrarilyRotated)
                    UseUniformScale = false;
            }

            Rect rect = EditorGUILayout.BeginHorizontal();
            {
                DoModeButtons(rect);

                GUILayout.Space(1);

                GUILayout.BeginVertical();
                {
                    Position.DoProperty();
                    Rotation.DoProperty();
                    Scale.DoProperty();
                }
                GUILayout.EndVertical();
            }
            GUILayout.EndHorizontal();

            DoWarnings();
        }

        /************************************************************************************************************************/
        #region Mode Buttons
        /************************************************************************************************************************/

        private static readonly float ModeButtonHeight = EditorGUIUtility.singleLineHeight * 3 + 2;
        private static readonly Quaternion ModeLabelRotation = Quaternion.Euler(0, 0, -90);

        //HACK: the Avatar Configuration scene screws with the indentation.
        [NonSerialized]
        private float _Indent = 14;

        /************************************************************************************************************************/

        private void DoModeButtons(Rect rect)
        {
            bool guiEnabled = GUI.enabled;

            // Indent the rest of the GUI (this is called inside a horizontal GUI layout region).

            if (rect.x != 0 && _Indent != rect.x)
            {
                _Indent = rect.x;
                Repaint();
            }

            GUILayout.Space(16 - _Indent);

            rect.x = 2;
            //rect.y += 2;
            rect.width = InternalGUI.SmallButtonStyle.fixedWidth;
            rect.height = InternalGUI.SmallButtonStyle.fixedHeight;

            // Local / World.
            if (GUI.Button(rect, CurrentIsLocalMode ? InternalGUI.LocalMode : InternalGUI.WorldMode, InternalGUI.SmallButtonStyle))
            {
                CurrentIsLocalMode = !CurrentIsLocalMode;
                Rotation.CacheEulerAngles();
                GUIUtility.hotControl = 0;
                GUIUtility.keyboardControl = 0;
            }

            float height = InternalGUI.SmallButtonStyle.fixedHeight + InternalGUI.SmallButtonStyle.padding.bottom;
            rect.y += height;

            if (!OverrideTransformGizmos)
                GUI.enabled = false;

            // Freeze Child Transforms.
            EditorGUI.BeginChangeCheck();
            CurrentFreezeChildTransforms = GUI.Toggle(rect, CurrentFreezeChildTransforms, InternalGUI.FreezeChildTransforms, InternalGUI.SmallButtonStyle);
            if (EditorGUI.EndChangeCheck())
            {
                SceneView.RepaintAll();
            }

            // Draw All Gizmos.
#if LITE
            GUI.enabled = false;
#endif

            rect.y += height;

            if (DrawAllGizmos.DrawToggle(rect, InternalGUI.DrawAllGizmos, InternalGUI.SmallButtonStyle))
            {
                SceneView.RepaintAll();
            }

            GUI.enabled = guiEnabled;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        private void DoWarnings()
        {
            if (!CurrentIsLocalMode && Rotation.IsArbitrarilyRotated)
            {
                EditorGUILayout.HelpBox(InternalGUI.ScaleSkewWarning, MessageType.Warning);
            }

            const float PositionWarningThreshold = 100000f;

            var position = Targets[0].position;
            if (Mathf.Abs(position.x) > PositionWarningThreshold ||
                Mathf.Abs(position.y) > PositionWarningThreshold ||
                Mathf.Abs(position.z) > PositionWarningThreshold)
            {
                EditorGUILayout.HelpBox(InternalGUI.PrecisionWarning, MessageType.Warning);
            }
        }

        /************************************************************************************************************************/

        private void OnSceneGUI()
        {
            if (!OverrideTransformGizmos)
                return;

            //Tools.hidden = false; return;

            TransformPropertyDrawer currentTool;
            switch (Tools.current)
            {
                case Tool.Move: currentTool = Position; break;
                case Tool.Rotate: currentTool = Rotation; break;
                case Tool.Scale: currentTool = Scale; break;
                default:
                    Tools.hidden = false;
                    return;
            }

            // Ignore controls while holding alt so it can control the camera without clicking on handles.
            if (Event.current.alt && Event.current.type != EventType.Repaint)
                return;

            Tools.hidden = true;

#if PRO
            if (DrawAllGizmos || target == Selection.activeTransform)
#else
            if (target == Selection.activeTransform)
#endif
            {
                DrawHandles(target as Transform, currentTool);
            }
        }

        /************************************************************************************************************************/

        private static readonly Color
            FrozenChildLineColor = new Color(1, 0, 0, 0.25f),
            FrozenChildDotColor = new Color(1, 0, 0, 0.5f);

        private void DrawHandles(Transform target, TransformPropertyDrawer currentTool)
        {
            Vector3 handlePosition = GetHandlePosition(target);

            currentTool.DrawTool(target, handlePosition);

            if (CurrentFreezeChildTransforms && Event.current.type == EventType.Repaint)
            {
                Vector3 parentPosition = target.position;

                for (int i = 0; i < target.childCount; i++)
                {
                    var child = target.GetChild(i);
                    Vector3 childPosition = child.position;

                    Handles.color = FrozenChildLineColor;
                    Handles.DrawLine(parentPosition, childPosition);
                    Handles.color = FrozenChildDotColor;

#if UNITY_5_6_OR_LATER
                    Handles.SphereHandleCap(0, childPosition, child.rotation, HandleUtility.GetHandleSize(childPosition) * 0.1f, EventType.Repaint);
#else
                    Handles.SphereCap(0, childPosition, child.rotation, HandleUtility.GetHandleSize(childPosition) * 0.1f);
#endif
                }

                Handles.color = Color.white;
            }
        }

        /************************************************************************************************************************/

        private static readonly PropertyInfo
            HandleOffset = typeof(Tools).GetProperty("handleOffset", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static),
            LocalHandleOffset = typeof(Tools).GetProperty("localHandleOffset", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);

        public static Vector3 GetHandlePosition(Transform target)
        {
#if DEBUG
            if (HandleOffset == null)
                Debug.LogError("Tools.handleOffset property not found");
            if (LocalHandleOffset == null)
                Debug.LogError("Tools.localHandleOffset property not found");
#endif

            if (target == null)
                return new Vector3(float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity);

            Vector3 offset;
            if (HandleOffset != null)
                offset = (Vector3)HandleOffset.GetValue(null, null);
            else
                offset = Vector3.zero;

            if (LocalHandleOffset != null)
                offset += Tools.handleRotation * (Vector3)LocalHandleOffset.GetValue(null, null);

            switch (Tools.pivotMode)
            {
                case PivotMode.Center:
#if PRO
                    if (DrawAllGizmos)
                        return CalculateBounds(target).center + offset;
                    else
#endif
                        return InternalEditorUtility.CalculateSelectionBounds(true, false).center + offset;

                case PivotMode.Pivot:
                default:
                    return target.position + offset;
            }
        }

        /************************************************************************************************************************/

        private static Bounds CalculateBounds(Transform target)
        {
            Bounds bounds = new Bounds();
            bool hasOrigin = false;

            var colliders = target.GetComponentsInChildren<Collider>();
            for (int i = 0; i < colliders.Length; i++)
                EncapsulateBounds(ref bounds, colliders[i].bounds, ref hasOrigin);

            var colliders2D = target.GetComponentsInChildren<Collider2D>();
            for (int i = 0; i < colliders2D.Length; i++)
                EncapsulateBounds(ref bounds, colliders2D[i].bounds, ref hasOrigin);

            var renderers = target.GetComponentsInChildren<Renderer>();
            for (int i = 0; i < renderers.Length; i++)
                EncapsulateBounds(ref bounds, renderers[i].bounds, ref hasOrigin);

            if (!hasOrigin)
                bounds.center = target.position;

            return bounds;
        }

        private static void EncapsulateBounds(ref Bounds bounds, Bounds encapsulate, ref bool hasOrigin)
        {
            if (!hasOrigin)
            {
                hasOrigin = true;
                bounds = encapsulate;
            }
            else
            {
                bounds.Encapsulate(encapsulate);
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif