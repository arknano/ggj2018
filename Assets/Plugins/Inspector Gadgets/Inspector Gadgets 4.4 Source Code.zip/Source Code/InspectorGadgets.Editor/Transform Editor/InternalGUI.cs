﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    internal static class InternalGUI
    {
        /************************************************************************************************************************/

        public static readonly float
            NameLabelWidth;

        public static readonly GUILayoutOption[]
            NameLabelOptions,
            ScaleLabelOptions,
            VectorFieldOptions;

        public static readonly GUIStyle
            FieldLabelStyle,
            FloatFieldStyle,
            SmallButtonStyle,
            UniformScaleButtonStyle,
            ModeButtonStyle,
            ModeLabelStyle;

        public const string
            LocalWorldTooltip = "[L] Local position/rotation/scale\n[W] World position/rotation/scale",
            ScaleModeTooltip = "[=] Uniform scale\n[≠] Non-uniform scale";

        public static readonly GUIContent
            X = new GUIContent("X"),
            Y = new GUIContent("Y"),
            Z = new GUIContent("Z"),
            LocalMode = new GUIContent("L", LocalWorldTooltip),
            WorldMode = new GUIContent("W", LocalWorldTooltip),
            FreezeChildTransforms = new GUIContent("F", "Freeze child transforms?"),
            DrawAllGizmos = new GUIContent("G", "Draw gizmos for all selected objects?"),
            Copy = new GUIContent("C", "Left Click = Copy to clipboard\nRight Click = Log current value"),
            Reset = new GUIContent("R", "Reset"),
            UniformScale = new GUIContent("≠", ScaleModeTooltip),
            NonUniformScale = new GUIContent("=", ScaleModeTooltip);

        public static readonly string
            ScaleSkewWarning = "An arbitrarily rotated object cannot have its World Scale properly represented by a Vector3 because it may be skewed, so the value may not be accurate.",
            PrecisionWarning = "Due to floating-point precision limitations, it is recommended to bring the world coordinates of the GameObject within a smaller range.";

        /************************************************************************************************************************/

        static InternalGUI()
        {
            FieldLabelStyle = new GUIStyle(EditorStyles.label)
            {
                fontStyle = FontStyle.Bold,
                margin = new RectOffset(0, 0, 2, 2),
            };

            NameLabelWidth = FieldLabelStyle.CalcSize(new GUIContent("Rotation")).x;
            NameLabelOptions = new GUILayoutOption[] { GUILayout.Width(NameLabelWidth) };
            ScaleLabelOptions = new GUILayoutOption[] { GUILayout.Width(NameLabelWidth - 17) };
            VectorFieldOptions = new GUILayoutOption[] { GUILayout.MinWidth(EditorGUIUtility.singleLineHeight) };

            FloatFieldStyle = EditorStyles.numberField;

            SmallButtonStyle = new GUIStyle(EditorStyles.miniButton)
            {
                margin = new RectOffset(0, 0, 2, 0),
                padding = new RectOffset(2, 3, 2, 2),
                alignment = TextAnchor.MiddleCenter,
                fixedHeight = EditorGUIUtility.singleLineHeight,
                fixedWidth = EditorGUIUtility.singleLineHeight - 1
            };

            UniformScaleButtonStyle = new GUIStyle(SmallButtonStyle)
            {
                margin = new RectOffset(2, 0, 2, 0),
                padding = new RectOffset(1, 3, -2, 0),
                fontSize = (int)EditorGUIUtility.singleLineHeight - 1
            };

            ModeLabelStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter
            };

            ModeButtonStyle = new GUIStyle(GUI.skin.button)
            {
                padding = new RectOffset()
            };
        }

        /************************************************************************************************************************/
    }
}

#endif