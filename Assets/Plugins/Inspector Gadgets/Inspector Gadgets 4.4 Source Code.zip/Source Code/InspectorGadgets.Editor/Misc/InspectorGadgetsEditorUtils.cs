// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    public static partial class InspectorGadgetsUtils
    {
        /************************************************************************************************************************/

        internal const string PrefsKeyPrefix = nameof(InspectorGadgets) + ".";

        /************************************************************************************************************************/
        #region Menu Items
        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Transform/Inspector Gadgets Manual")]
        internal static void OpenManual()
        {
            string path = Path.GetDirectoryName(typeof(InspectorGadgetsUtils).Assembly.Location) + @"\Manual.pdf";

            if (File.Exists(path))
                EditorUtility.OpenWithDefaultApp(path);
            else
                Debug.LogWarning("Inspector Gadgets Manual file does not exist at " + path);
        }

        /************************************************************************************************************************/

#if PRO// New Locked Inspector.
        [MenuItem("Edit/Selection/New Locked Inspector %&S")]
        [MenuItem("CONTEXT/Transform/New Locked Inspector %&S")]
        internal static void NewLockedInspector()
        {
            var type = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
            if (type == null)
            {
                Debug.LogWarning("Unable to find InspectorWindow class in " + typeof(Editor).Assembly.Location);
                return;
            }

            var window = ScriptableObject.CreateInstance(type) as EditorWindow;
            window.Show();

            var isLocked = type.GetProperty("isLocked", BindingFlags.Instance | BindingFlags.Public);
            isLocked.GetSetMethod().Invoke(window, new object[] { true });
        }
#endif

        /************************************************************************************************************************/

        [MenuItem("GameObject/Reset Selected Transforms %#Z")]
        private static void ResetSelectedTransforms()
        {
            if (Selection.gameObjects.Length > 1)// Multiple Objects.
            {
                Undo.RecordObjects(Selection.gameObjects, "Reset Transforms");
                for (int i = 0; i < Selection.gameObjects.Length; i++)
                {
                    Transform trans = Selection.gameObjects[i].transform;
                    trans.localPosition = Vector3.zero;
                    trans.localRotation = Quaternion.identity;
                    trans.localScale = Vector3.one;
                }
            }
            else if (Selection.gameObjects.Length == 1)// Single Object.
            {
                Transform trans = Selection.gameObjects[0].transform;
                Undo.RecordObject(trans, "Reset Transform");
                trans.localPosition = Vector3.zero;
                trans.localRotation = Quaternion.identity;
                trans.localScale = Vector3.one;
            }
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/MonoBehaviour/Ping Script Asset")]
        private static void PingScriptAsset(MenuCommand menuCommand)
        {
            PingScriptAsset(menuCommand.context);
        }

        internal static void PingScriptAsset(UnityEngine.Object obj)
        {
            MonoScript script;

            if (obj is MonoBehaviour behaviour)
                script = MonoScript.FromMonoBehaviour(behaviour);
            else if (obj is ScriptableObject scriptable)
                script = MonoScript.FromScriptableObject(scriptable);
            else
                return;

            if (script != null)
                EditorGUIUtility.PingObject(script);
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Transform/Copy Transform Path")]
        private static void CopyTransformPath(MenuCommand menuCommand)
        {
            var text = new StringBuilder();
            AppendTransformPath(text, menuCommand.context as Transform);
            EditorGUIUtility.systemCopyBuffer = text.ToString();
        }

        /************************************************************************************************************************/
        #region Create Editor Script
#if PRO
        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Component/Create Editor Script")]
        private static void CreateEditorScript(MenuCommand command)
        {
            if (!EditorApplication.isPlayingOrWillChangePlaymode)
                CreateEditorScript(command.context);
        }

        internal static void CreateEditorScript(UnityEngine.Object target)
        {
            string path = AskForEditorScriptSavePath(target);
            if (path == null)
                return;

            Directory.CreateDirectory(Path.GetDirectoryName(path));

            string editorName = Path.GetFileNameWithoutExtension(path);

            File.WriteAllText(path, BuildEditorScript(target, editorName));

            Debug.Log(editorName + " script created at " + path);

            AssetDatabase.ImportAsset(path);
            AssetDatabase.OpenAsset(AssetDatabase.LoadAssetAtPath<MonoScript>(path));
        }

        /************************************************************************************************************************/

        private static string FindComponentDirectory(UnityEngine.Object component)
        {
            if (component is MonoBehaviour behaviour)
            {
                MonoScript script = MonoScript.FromMonoBehaviour(behaviour);
                if (script != null)
                {
                    return Path.GetDirectoryName(AssetDatabase.GetAssetPath(script));
                }
            }

            return "Assets";
        }

        /************************************************************************************************************************/

        private static string AskForEditorScriptSavePath(UnityEngine.Object target)
        {
            string path = FindComponentDirectory(target);
            string name = target.GetType().Name;
            string fileName = name + "Editor.cs";

            int dialogResult = EditorUtility.DisplayDialogComplex(
                "Create Editor Script",
                string.Concat("Create Editor Script for ", name, " at ", path, "/", fileName),
                "Create", "Browse", "Cancel");

            switch (dialogResult)
            {
                case 0:// Create.
                    return path + "/" + fileName;

                case 1:// Browse.
                    return EditorUtility.SaveFilePanelInProject("Create Editor Script", fileName, "cs",
                        "Where do you want to save the Editor Script for " + name + "?", path);

                default:// Cancel.
                    return null;
            }
        }

        /************************************************************************************************************************/

        private static string BuildEditorScript(UnityEngine.Object target, string editorName)
        {
            var type = target.GetType();

            var text = new StringBuilder();
            text.AppendLine("#if UNITY_EDITOR");
            text.AppendLine();
            text.AppendLine("using UnityEditor;");
            text.AppendLine("using UnityEngine;");
            text.AppendLine();

            bool indent = false;
            if (type.Namespace != null)
            {
                text.Append("namespace ").AppendLine(type.Namespace);
                text.AppendLine("{");
                indent = true;

                text.Append("    ");
            }

            text.Append("[CustomEditor(typeof(");
            text.Append(type.Name);
            text.AppendLine("), true)]");

            if (indent) text.Append("    ");
            text.Append("sealed class ");
            text.Append(editorName);
            text.Append(" : InspectorGadgets.Editor<");
            text.Append(type.Name);
            text.AppendLine(">");

            if (indent) text.Append("    ");
            text.AppendLine("{");

            if (indent) text.Append("    ");
            text.AppendLine("}");

            if (indent) text.AppendLine("}");

            text.AppendLine();
            text.Append("#endif");

            return text.ToString();
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Snapping
        /************************************************************************************************************************/

        /// <summary>[Editor-Only] The Unity editor's "Move X" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float MoveSnapX
        {
            get { return EditorPrefs.GetFloat("MoveSnapX", 1); }
            set { EditorPrefs.SetFloat("MoveSnapX", value); }
        }

        /// <summary>[Editor-Only] The Unity editor's "Move Y" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float MoveSnapY
        {
            get { return EditorPrefs.GetFloat("MoveSnapY", 1); }
            set { EditorPrefs.SetFloat("MoveSnapY", value); }
        }

        /// <summary>[Editor-Only] The Unity editor's "Move Z" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float MoveSnapZ
        {
            get { return EditorPrefs.GetFloat("MoveSnapZ", 1); }
            set { EditorPrefs.SetFloat("MoveSnapZ", value); }
        }

        /// <summary>[Editor-Only] (<see cref="MoveSnapX"/>, <see cref="MoveSnapY"/>, <see cref="MoveSnapZ"/>).</summary>
        public static Vector3 MoveSnapVector
        {
            get
            {
                return new Vector3(MoveSnapX, MoveSnapY, MoveSnapZ);
            }
            set
            {
                MoveSnapX = value.x;
                MoveSnapY = value.y;
                MoveSnapZ = value.z;
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] The Unity editor's "Rotation" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float RotationSnap
        {
            get { return EditorPrefs.GetFloat("RotationSnap", 15); }
            set { EditorPrefs.SetFloat("RotationSnap", value); }
        }

        /// <summary>[Editor-Only] (<see cref="RotationSnap"/>, <see cref="RotationSnap"/>, <see cref="RotationSnap"/>).</summary>
        public static Vector3 RotationSnapVector
        {
            get
            {
                float snap = RotationSnap;
                return new Vector3(snap, snap, snap);
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] The Unity editor's "Scale" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float ScaleSnap
        {
            get { return EditorPrefs.GetFloat("ScaleSnap", 0.1f); }
            set { EditorPrefs.SetFloat("ScaleSnap", value); }
        }

        /// <summary>[Editor-Only] (<see cref="ScaleSnap"/>, <see cref="ScaleSnap"/>, <see cref="ScaleSnap"/>).</summary>
        public static Vector3 ScaleSnapVector
        {
            get
            {
                float snap = ScaleSnap;
                return new Vector3(snap, snap, snap);
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'value' to a grid with the specified 'snap' size.</summary>
        public static float Snap(float value, float snap)
        {
            return Mathf.Round(value / snap) * snap;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'position' to the grid (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapPosition(Vector3 position)
        {
            float snap = MoveSnapX;
            position.x = Snap(position.x, snap);

            snap = MoveSnapY;
            position.y = Snap(position.y, snap);

            snap = MoveSnapZ;
            position.z = Snap(position.z, snap);

            return position;
        }

        /// <summary>[Editor-Only] Snaps the given 'position' to the grid on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapPosition(Vector3 position, int axisIndex)
        {
            position[axisIndex] = Snap(position[axisIndex], MoveSnapVector[axisIndex]);
            return position;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'rotationEuler' to the nearest snap increment on all axes (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapRotation(Vector3 rotationEuler)
        {
            float snap = RotationSnap;
            rotationEuler.x = Snap(rotationEuler.x, snap);
            rotationEuler.y = Snap(rotationEuler.y, snap);
            rotationEuler.z = Snap(rotationEuler.z, snap);
            return rotationEuler;
        }

        /// <summary>[Editor-Only] Snaps the given 'rotationEuler' to the nearest snap increment on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapRotation(Vector3 rotationEuler, int axisIndex)
        {
            rotationEuler[axisIndex] = Snap(rotationEuler[axisIndex], RotationSnap);
            return rotationEuler;
        }

        /// <summary>[Editor-Only] Snaps the given 'rotation' to the nearest snap increment on all axes (as specified in Edit/Snap Settings).</summary>
        public static Quaternion SnapRotation(Quaternion rotation)
        {
            return Quaternion.Euler(SnapRotation(rotation.eulerAngles));
        }

        /// <summary>[Editor-Only] Snaps the given 'rotation' to the nearest snap increment on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Quaternion SnapRotation(Quaternion rotation, int axisIndex)
        {
            return Quaternion.Euler(SnapRotation(rotation.eulerAngles, axisIndex));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'scale' to the nearest snap increment on all axes (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapScale(Vector3 scale)
        {
            float snap = ScaleSnap;
            scale.x = Snap(scale.x, snap);
            scale.y = Snap(scale.y, snap);
            scale.z = Snap(scale.z, snap);
            return scale;
        }

        /// <summary>[Editor-Only] Snaps the given 'scale' to the nearest snap increment on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapScale(Vector3 scale, int axisIndex)
        {
            scale[axisIndex] = Snap(scale[axisIndex], ScaleSnap);
            return scale;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Returns true if 'value' is approximately equal to a multiple of 'snap'.</summary>
        public static bool IsSnapped(float value, float snap)
        {
            return Mathf.Approximately(value, Mathf.Round(value / snap) * snap);
        }

        /************************************************************************************************************************/

        [MenuItem("GameObject/Snap to Grid %#X")]
        private static void SnapSelectionToGrid()
        {
            var transforms = Selection.GetTransforms(SelectionMode.TopLevel | SelectionMode.OnlyUserModifiable);

            Undo.RecordObjects(transforms, "Snap to Grid");
            for (int i = 0; i < transforms.Length; i++)
            {
                var transform = transforms[i];
                transform.localPosition = SnapPosition(transform.localPosition);
                transform.localRotation = SnapRotation(transform.localRotation);
                transform.localScale = SnapScale(transform.localScale);
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Get Value from SerializedProperty
        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Gets the actual target object of the <see cref="SerializedProperty"/>.</summary>
        public static object GetValue(SerializedProperty property, int backtrack = 0)
        {
            return GetValue(property, property.serializedObject.targetObject, backtrack);
        }

        /// <summary>[Editor-Only] Gets the actual target object of the <see cref="SerializedProperty"/>.</summary>
        public static T GetValue<T>(SerializedProperty property, int backtrack = 0)
        {
            return (T)GetValue(property, backtrack);
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Gets the actual target objects of the <see cref="SerializedProperty"/>.</summary>
        public static T[] GetValues<T>(SerializedProperty property, int backtrack = 0)
        {
            var targetObjects = property.serializedObject.targetObjects;
            T[] values = new T[targetObjects.Length];
            for (int i = 0; i < values.Length; i++)
            {
                values[i] = (T)GetValue(property, targetObjects[i], backtrack);
            }

            return values;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Gets the actual target object of the <see cref="SerializedProperty"/>.</summary>
        public static object GetValue(SerializedProperty property, object targetObject, int backtrack = 0)
        {
            var path = property.propertyPath.Replace(".Array.data[", "[");

            var elements = path.Split('.');
            for (int i = 0; i < elements.Length - backtrack; i++)
            {
                var element = elements[i];

                int openBracket = element.IndexOf('[');
                if (openBracket >= 0)
                {
                    var elementName = element.Substring(0, openBracket);
                    var index = Convert.ToInt32(element.Substring(openBracket).Replace("[", "").Replace("]", ""));
                    targetObject = GetValue(targetObject, elementName, index);
                }
                else
                {
                    targetObject = GetValue(targetObject, element);
                }
            }

            return targetObject;
        }

        /************************************************************************************************************************/

        private static object GetValue(object targetObject, string memberName)
        {
            if (targetObject == null)
                return null;

            var type = targetObject.GetType();

            do
            {
                var field = type.GetField(memberName, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
                if (field != null)
                    return field.GetValue(targetObject);

                var property = type.GetProperty(memberName, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (property != null)
                    return property.GetValue(targetObject, null);

                type = type.BaseType;
            }
            while (type != null);

            return null;
        }

        /************************************************************************************************************************/

        private static object GetValue(object targetObject, string memberName, int index)
        {
            targetObject = GetValue(targetObject, memberName);

            if (targetObject is IList list)
            {
                if (index < list.Count)
                    return list[index];
                else
                    return null;
            }

            var enumerable = targetObject as IEnumerable;
            var enumerator = enumerable.GetEnumerator();

            while (index-- >= 0)
            {
                if (!enumerator.MoveNext())
                    return null;
            }

            return enumerator.Current;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Tries to find and return the underlying <see cref="FieldInfo"/> encapsulated by the specified 'property'.</summary>
        public static FieldInfo TryGetFieldInfo(SerializedProperty property, out Type propertyType)
        {
            propertyType = property.serializedObject.targetObject.GetType();
            FieldInfo field = null;

            var path = property.propertyPath.Replace(".Array.data[", "[");

            var elements = path.Split('.');

            for (int i = 0; i < elements.Length; i++)
            {
                var element = elements[i];

                int openBracket = element.IndexOf('[');
                if (openBracket >= 0)
                {
                    element = element.Substring(0, openBracket);
                }

                while (true)
                {
                    field = propertyType.GetField(element, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
                    if (field != null)
                        break;

                    propertyType = propertyType.BaseType;
                    if (propertyType == null)
                        return null;
                }

                propertyType = field.FieldType;

                if (openBracket >= 0)
                {
                    if (propertyType.IsArray)
                    {
                        propertyType = propertyType.GetElementType();
                    }
                    else if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(List<>))
                    {
                        propertyType = propertyType.GetGenericArguments()[0];
                    }
                }
            }

            return field;
        }

        /// <summary>[Editor-Only] Tries to find and return the underlying <see cref="FieldInfo"/> encapsulated by the specified 'property'.</summary>
        public static FieldInfo TryGetFieldInfo(SerializedProperty property)
        {
            return TryGetFieldInfo(property, out var propertyType);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Calls the specified 'method' for each of the underlying values of the 'property' (in case it represents
        /// multiple selected objects) and records an undo step for any modifications made.
        /// </summary>
        public static void ModifyValues<T>(SerializedProperty property, Action<T> method, string undoName)
        {
            Undo.RecordObjects(property.serializedObject.targetObjects, undoName);

            var values = InspectorGadgetsUtils.GetValues<T>(property);
            for (int i = 0; i < values.Length; i++)
            {
                method(values[i]);
            }

            // If this change is made to a prefab, this makes sure that any instances in the scene will be updated.
            for (int i = 0; i < property.serializedObject.targetObjects.Length; i++)
            {
                EditorUtility.SetDirty(property.serializedObject.targetObjects[i]);
            }

            property.serializedObject.Update();
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Draw the target and name of the specified <see cref="Delegate"/>.
        /// </summary>
        public static void DrawDelegate(Rect position, Delegate del)
        {
            float width = position.width;

            position.xMax = UnityEditor.EditorGUIUtility.labelWidth + 15;
            if (del.Target is UnityEngine.Object obj)
            {
                // If the target is a Unity Object, draw it in an Object Field so the user can click to ping the object.

                using (new UnityEditor.EditorGUI.DisabledScope(true))
                {
                    UnityEditor.EditorGUI.ObjectField(position, obj, typeof(UnityEngine.Object), true);
                }
            }
            else if (del.Method.DeclaringType.IsDefined(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute), true))
            {
                // Anonymous Methods draw only their method name.

                position.width = width;

                GUI.Label(position, del.Method.GetNameCS());

                return;
            }
            else if (del.Target == null)
            {
                GUI.Label(position, del.Method.DeclaringType.GetNameCS());
            }
            else
            {
                GUI.Label(position, del.Target.ToString());
            }

            position.x += position.width;
            position.width = width - position.width;

            GUI.Label(position, del.Method.GetNameCS(false));
        }

        /************************************************************************************************************************/
    }
}

#endif