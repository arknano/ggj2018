// Inspector Gadgets // Copyright 2018 Kybernetik //

// This script is based on a concept created by Astral Byte Ltd: http://www.astralbyte.co.nz/code/AutoHideUILayer.cs.
// It has been heavily modified and improved for use in Inspector Gadgets, but the core concept is the same.

#pragma warning disable CS0618 // HACK: Type or member is obsolete: EditorApplication.playmodeStateChanged

#if UNITY_EDITOR

using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>
    /// Automatically hides the UI layer inside the Editor so it doesn't get in the way of 3D objects in scene view.
    ///<para></para>
    /// When any object is selected that is on the UI layer, the layer will be shown and the camera changed to 2D orthographic and zoomed to the current selection.
    ///<para></para>
    /// When any object on another layer is selected, the UI layer will be hidden and the camera changed back to the previous state.
    /// </summary>
    [InitializeOnLoad]
    internal static class AutoHideUI
    {
        /************************************************************************************************************************/

        public const int
            UiLayer = 5,
            UILayerMask = 1 << UiLayer;

        private static readonly AutoPrefs.EditorBool
            IsEnabled = InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(AutoHideUI),
            Previous2dMode = InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(Previous2dMode),
            PreviousOrthographicMode = InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(PreviousOrthographicMode);

        private static readonly AutoPrefs.EditorVector3
            PreviousPivot = InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(PreviousPivot);

        private static readonly AutoPrefs.EditorQuaternion
            PreviousRotation = InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(PreviousRotation);

        private static readonly AutoPrefs.EditorFloat
            PreviousSize = InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(PreviousSize);

        private static bool
            _IsShowingUI;

        /************************************************************************************************************************/

        static AutoHideUI()
        {
            EditorApplication.delayCall += () =>
            {
                if (!IsEnabled.IsSaved())
                {
                    Selection.selectionChanged += OnFirstRun;
                }
                else if (IsEnabled)
                {
                    _IsShowingUI = ShouldShow();
                    Selection.selectionChanged += OnSelectionChanged;
                    EditorApplication.playmodeStateChanged += OnSelectionChanged;

                    bool isUiLayerShowing = (Tools.visibleLayers & UILayerMask) == UILayerMask;

                    if (_IsShowingUI != isUiLayerShowing && Previous2dMode.IsSaved())
                    {
                        _IsShowingUI = !_IsShowingUI;
                        OnSelectionChanged();
                    }
                }
            };
        }

        /************************************************************************************************************************/

        private static void OnFirstRun()
        {
            if (!ShouldShow())
                return;

            Selection.selectionChanged -= OnFirstRun;

            IsEnabled.Value = false;

            const string FirstRunMessage =
@"Would you like Inspector Gadgets to automatically show and hide the UI layer?
 
On UI selected: show UI layer, enter 2D orthographic mode, and focus the camera on the selected object.

On UI deselected: hide UI layer and return camera to the previous state.

You can turn this feature on/off via the Inspector Gadgets tab in the Edit/Preferences menu.";

            if (EditorUtility.DisplayDialog("Auto Hide UI", FirstRunMessage, "Enable", "Do Nothing"))
            {
                IsEnabled.Value = true;
                EditorApplication.delayCall += Enable;
            }
        }

        /************************************************************************************************************************/

        private static readonly GUIContent
            EnabledToggleContent = new GUIContent("Auto Hide UI",
                "If enabled, the UI layer will be automatically hidden until a UI object is selected.");

        public static void DrawEnabledToggle()
        {
            if (IsEnabled.DrawToggle(EnabledToggleContent))
            {
                if (IsEnabled)
                {
                    Enable();
                }
                else
                {
                    Selection.selectionChanged -= OnSelectionChanged;
                    EditorApplication.playmodeStateChanged -= OnSelectionChanged;
                    HideUI();
                    Tools.visibleLayers |= UILayerMask;
                }
            }
        }

        private static void Enable()
        {
            Selection.selectionChanged += OnSelectionChanged;
            EditorApplication.playmodeStateChanged += OnSelectionChanged;
            OnSelectionChanged();
        }

        /************************************************************************************************************************/

        private static bool ShouldShow()
        {
            var activeGameObject = Selection.activeGameObject;
            return
                activeGameObject != null &&
                activeGameObject.layer == UiLayer &&
                !EditorUtility.IsPersistent(activeGameObject);
        }

        /************************************************************************************************************************/

        private static void OnSelectionChanged()
        {
            if (ShouldShow())
                ShowUI();
            else
                HideUI();
        }

        /************************************************************************************************************************/

        private static void ShowUI()
        {
            if (_IsShowingUI)
                return;

            var sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null)
                return;

            // Store the current scene view state.
            Previous2dMode.Value = sceneView.in2DMode;
            PreviousOrthographicMode.Value = sceneView.orthographic;
            PreviousPivot.Value = sceneView.pivot;
            PreviousRotation.Value = sceneView.rotation;
            PreviousSize.Value = sceneView.size;

            // Apply UI mode and show the UI layer.
            sceneView.in2DMode = true;
            sceneView.orthographic = true;
            sceneView.FrameSelected();
            Tools.visibleLayers |= UILayerMask;
            _IsShowingUI = true;
        }

        /************************************************************************************************************************/

        private static void HideUI()
        {
            if (!_IsShowingUI)
                return;

            var sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null)
                return;

            // Return to the stored scene view state and hide the UI layer.
            sceneView.in2DMode = Previous2dMode;
            sceneView.LookAt(PreviousPivot, PreviousRotation, PreviousSize, PreviousOrthographicMode);
            Tools.visibleLayers &= ~UILayerMask;
            _IsShowingUI = false;
        }

        /************************************************************************************************************************/

        [OnEditorQuit]
        private static void OnEditorQuit()
        {
            // If we are currently enabled when the editor closes, show the UI layer in case the next project the user
            // opens doesn't have this script.

            if (IsEnabled)
            {
                Tools.visibleLayers |= UILayerMask;
            }
        }

        /************************************************************************************************************************/
    }
}

#endif