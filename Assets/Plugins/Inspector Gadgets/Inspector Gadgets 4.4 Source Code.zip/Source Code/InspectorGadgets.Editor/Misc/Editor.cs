// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
#if PRO
    [CustomEditor(typeof(Component), true)]
    [CanEditMultipleObjects]
    internal sealed class ComponentEditor : Editor<Component>
    {
        // This is here because having it in the generic base class would make a new instance for each generic subtype.
        public static readonly AutoPrefs.EditorBool
            HideScriptProperty = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(HideScriptProperty), true);
    }

    [CustomEditor(typeof(ScriptableObject), true)]
    [CanEditMultipleObjects]
    internal sealed class ScriptableObjectEditor : Editor<ScriptableObject> { }

    [CustomEditor(typeof(StateMachineBehaviour), true)]
    [CanEditMultipleObjects]
    internal sealed class StateMachineBehaviourEditor : Editor<StateMachineBehaviour> { }
#endif

    /************************************************************************************************************************/

    /// <summary>[Pro-Only]
    /// Base class to derive custom editors from, with a bunch of additional features on top of Unity's base
    /// <see cref="Editor"/> class.
    /// <para></para>
    /// Doesn't draw the target's "Script" field to save inspector space and reduce clutter.
    /// <para></para>
    /// You can Middle Click anywhere in the inspector area to open the script in your script editor or Ctrl + Middle
    /// Click to open its editor script (or create one if none exists already).
    /// <para></para>
    /// Provides type-casted versions of <see cref="Editor.target"/> and <see cref="Editor.targets"/> so you don't
    /// always have to do it yourself (<see cref="Target"/> and <see cref="Targets"/> respectively).
    /// </summary>
    public abstract class Editor<T> : Editor where T : UnityEngine.Object
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/
#if PRO
        /************************************************************************************************************************/

        private const string ScriptFieldName = "m_Script";

        private List<InspectableAttribute> _Inspectables;

        private Action _OnInspectorGUI, _AfterInspectorGUI;

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/

        /// <summary>The editor currently being drawn.</summary>
        public static Editor<T> Current { get; private set; }

        /// <summary>The object being inspected (<see cref="Editor.target"/> casted to T).</summary>
        public static T Target { get; private set; }

        /// <summary>An array of all objects being inspected (<see cref="Editor.targets"/> casted to T).</summary>
        public static T[] Targets { get; private set; }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Initialisation
        /************************************************************************************************************************/

        /// <summary>
        /// Gathers all of the target's inspectables (<see cref="ButtonAttribute"/> and <see cref="LabelAttribute"/>)
        /// and checks for inspector GUI events in the script.
        /// </summary>
        protected virtual void OnEnable()
        {
#if PRO
            if (target != null)
            {
                var type = target.GetType();

                if (_Inspectables == null)
                    _Inspectables = InspectableAttribute.Gather(type);

                if (_OnInspectorGUI == null)
                {
                    _OnInspectorGUI = TryGetInspectorEvent(type, "OnInspectorGUI", OnInspectorGUIEvents);
                    if (_OnInspectorGUI == null && _AfterInspectorGUI == null)
                        _AfterInspectorGUI = TryGetInspectorEvent(type, "AfterInspectorGUI", AfterInspectorGUIEvents);
                }
            }
#endif
        }

        /************************************************************************************************************************/
#if PRO
        /************************************************************************************************************************/

        private static readonly Dictionary<Type, MethodInfo>
            OnInspectorGUIEvents = new Dictionary<Type, MethodInfo>(),
            AfterInspectorGUIEvents = new Dictionary<Type, MethodInfo>();

        /************************************************************************************************************************/

        private Action TryGetInspectorEvent(Type type, string name, Dictionary<Type, MethodInfo> events)
        {
            var method = TryGetInspectorEventMethod(type, "AfterInspectorGUI", AfterInspectorGUIEvents);
            if (method != null)
                return (Action)Delegate.CreateDelegate(typeof(Action), target, method);
            else
                return null;
        }

        private static MethodInfo TryGetInspectorEventMethod(Type type, string name, Dictionary<Type, MethodInfo> events)
        {
            if (!events.TryGetValue(type, out MethodInfo method))
            {
                method = type.GetMethod(
                    name,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static,
                    null,
                    Type.EmptyTypes,
                    null);

                events.Add(type, method);
            }

            return method;
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Execution
        /************************************************************************************************************************/

        /// <summary>Initialises <see cref="Target"/>.</summary>
        public void AcquireTarget()
        {
#if PRO
            Target = target as T;
#endif
        }

        /// <summary>Initialises <see cref="Target"/>, and <see cref="Targets"/>.</summary>
        public void AcquireTargets()
        {
#if PRO
            AcquireTarget();

            if (Targets == null || Targets.Length != targets.Length)
                Targets = new T[targets.Length];

            Targets[0] = Target;
            for (int i = 1; i < Targets.Length; i++)
                Targets[i] = targets[i] as T;
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws the target's regular inspector followed by any extra inspectables
        /// (<see cref="ButtonAttribute"/> and <see cref="LabelAttribute"/>), and responds to Middle
        /// Click events.
        /// <para></para>
        /// To modify or replace just the regular inspector and keep the extra features of <see cref="Editor{T}"/>,
        /// override <see cref="DoSerializedProperties()"/> instead of <see cref="OnInspectorGUI"/>.
        /// </summary>
        public override void OnInspectorGUI()
        {
#if PRO
            Current = this;

            if (_OnInspectorGUI != null)
                _OnInspectorGUI();
            else
                DoInspectorGUI();
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws the inspector GUI of the <see cref="Current"/> editor.
        /// </summary>
        public static void DoInspectorGUI()
        {
#if PRO
            Rect rect = EditorGUILayout.BeginVertical();

            if (Current.target == null || Current.serializedObject.targetObject == null)
            {
                Current.DoMissingScriptInspectorGUI();
            }
            else
            {
                Current.AcquireTargets();
                Current.DoSerializedProperties();
                Current.DoInspectables();
            }

            Current._AfterInspectorGUI?.Invoke();

            if (Current.serializedObject.ApplyModifiedProperties())
                Current.OnPropertyModified();

            EditorGUILayout.EndVertical();
            Current.CheckMiddleClick(rect);
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws the inspector GUI for a missing script.
        /// </summary>
        public void DoMissingScriptInspectorGUI()
        {
#if PRO
            serializedObject.Update();
            var scriptProperty = serializedObject.FindProperty(ScriptFieldName);
            EditorGUILayout.PropertyField(scriptProperty);

            EditorGUILayout.HelpBox("The associated script can not be loaded.\nPlease fix any compile errors and assign a valid script.", MessageType.Warning);

            if (!ReferenceEquals(target, null))
            {
                if (GUILayout.Button("Remove Component"))
                {
                    EditorApplication.delayCall += () =>
                    {
                        Undo.DestroyObjectImmediate(target);
                        UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
                    };
                }
            }
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws all of the target's serialized members excluding the "Script" field and calls
        /// <see cref="OnPropertyModified"/> if any of them are modified.
        /// </summary>
        public virtual void DoSerializedProperties()
        {
#if PRO
            DoSerializedProperties(serializedObject);
#endif
        }

        /// <summary>
        /// Draws all of the target's serialized members excluding the "Script" field and calls
        /// <see cref="OnPropertyModified"/> if any of them are modified.
        /// </summary>
        public static void DoSerializedProperties(SerializedObject serializedObject)
        {
#if PRO
            //DrawDefaultInspector(); return;

            serializedObject.Update();
            SerializedProperty property = serializedObject.GetIterator();

            if (!property.NextVisible(true))
                return;

            if (!ComponentEditor.HideScriptProperty || property.name != ScriptFieldName)
                EditorGUILayout.PropertyField(property, true);

            while (property.NextVisible(false))
            {
                EditorGUILayout.PropertyField(property, true);
            }
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws all the target's inspectables (<see cref="ButtonAttribute"/> and <see cref="LabelAttribute"/>).
        /// </summary>
        public void DoInspectables()
        {
#if PRO
            InspectableAttribute.DoAll(_Inspectables, targets, out bool repaint);

            if (repaint)
                Repaint();
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// This method is called if any of the target's serialized members are modified during <see cref="DoSerializedProperties()"/>.
        /// </summary>
        public virtual void OnPropertyModified() { }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the current event is a Middle Click to open the script in the user's script editor application,
        /// or Ctrl + Middle Click to open or create its custom inspector script.
        /// </summary>
        public virtual void CheckMiddleClick(Rect rect)
        {
#if PRO
            rect.yMin -= 16;// Move the top of the rect up to include the component's title bar.

            if (Event.current.type == EventType.MouseUp &&
                Event.current.button == 2 &&
                rect.Contains(Event.current.mousePosition))
            {
                if (Event.current.control)// Ctrl + Middle click to open or create the editor script.
                {
                    var script = MonoScript.FromScriptableObject(this);
                    if (script != null && GetType().Assembly != typeof(Editor<>).Assembly)
                        AssetDatabase.OpenAsset(script);
                    else
                        InspectorGadgetsUtils.CreateEditorScript(target);
                }
                else if (Event.current.shift)// Shift + Middle click to ping the script asset.
                {
                    InspectorGadgetsUtils.PingScriptAsset(target);
                }
                else// Middle click to open the script.
                {
                    if (target is MonoBehaviour behaviour)
                        AssetDatabase.OpenAsset(MonoScript.FromMonoBehaviour(behaviour));
                    else if (target is ScriptableObject scriptable)
                        AssetDatabase.OpenAsset(MonoScript.FromScriptableObject(scriptable));
                }
            }
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Records the current state of the <see cref="Target"/> or <see cref="Targets"/> so that any subsequent
        /// changes can be undone (reverted back to the recorded state).
        /// </summary>
        public static void RecordTargetUndo(string undoName)
        {
            if (Targets.Length == 0)
                Undo.RecordObject(Target, undoName);
            else
                Undo.RecordObjects(Targets, undoName);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif