﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR && PRO

using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    [CustomPropertyDrawer(typeof(Object), true)]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class ObjectDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        public static readonly AutoPrefs.EditorInt
            ObjectEditorNestLimit = new AutoPrefs.EditorInt(InspectorGadgetsUtils.PrefsKeyPrefix + "." + nameof(ObjectEditorNestLimit), 3);

        private static readonly HashSet<Editor>
            AllEditors = new HashSet<Editor>();

        private static int _NestLevel;

        private GUIStyle _NestAreaStyle;
        private Editor _TargetEditor;

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            EditorGUI.PropertyField(position, property, label, property.isExpanded);

            if (_NestLevel < ObjectEditorNestLimit &&
                !property.hasMultipleDifferentValues &&
                property.objectReferenceValue != null &&
                !(property.objectReferenceValue is GameObject))// The Editor for a GameObject draws nothing. It would need to draw another whole inspector.
            {
                _NestLevel++;

                property.isExpanded = EditorGUI.Foldout(position, property.isExpanded, GUIContent.none, true);
                if (property.isExpanded)
                {
                    const float NegativePadding = 4;
                    EditorGUIUtility.labelWidth -= NegativePadding;

                    if (_NestAreaStyle == null)
                    {
                        _NestAreaStyle = new GUIStyle(GUI.skin.box);
                        var rect = _NestAreaStyle.margin;
                        rect.bottom = rect.top = 0;
                        _NestAreaStyle.margin = rect;
                    }

                    EditorGUI.indentLevel++;
                    GUILayout.BeginVertical(_NestAreaStyle);

                    try
                    {
                        if (_TargetEditor == null || _TargetEditor.target != property.objectReferenceValue)
                        {
                            if (_TargetEditor != null)
                            {
                                AllEditors.Remove(_TargetEditor);
                                Object.DestroyImmediate(_TargetEditor);
                            }

                            _TargetEditor = Editor.CreateEditor(property.objectReferenceValue);
                            AllEditors.Add(_TargetEditor);
                        }

                        _TargetEditor.OnInspectorGUI();
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogException(ex);
                    }

                    GUILayout.EndVertical();
                    EditorGUI.indentLevel--;

                    EditorGUIUtility.labelWidth += NegativePadding;
                }

                _NestLevel--;
            }
        }

        /************************************************************************************************************************/

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUI.GetPropertyHeight(property, label, true);
        }

        /************************************************************************************************************************/

        static ObjectDrawer()
        {
            Selection.selectionChanged += DestroyOldEditors;
        }

        [OnWillUnloadAssemblies]
        private static void DestroyOldEditors()
        {
            foreach (var editor in AllEditors)
            {
                Object.DestroyImmediate(editor);
            }

            AllEditors.Clear();
        }

        /************************************************************************************************************************/
    }
}

#endif