// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    internal static class Preferences
    {
        /************************************************************************************************************************/

        private static readonly GUIContent
            // Transform Inspector.
            ShowCopyButton = new GUIContent("Show Copy Button",
                "If enabled, the Transform Inspector will show the [C] button to copy a transform property to an internal clipboard."),
            ShowPasteButton = new GUIContent("Show Paste Button",
                "If enabled, the Transform Inspector will show the [P] button to paste a transform property from the internal clipboard."),
            ShowSnapButton = new GUIContent("Show Snap Button",
                "If enabled, the Transform Inspector will show the [S] button to snap a transform property to the nearest snap increment specified in Edit/Snap Setings."),
            ShowResetButton = new GUIContent("Show Reset Button",
                "If enabled, the Transform Inspector will show the [R] button to reset a transform property to its default value."),
            DisableUselessButtons = new GUIContent("Disable Useless Buttons",
                "If enabled, the [C/P/R/S] buttons will be greyed out when they would do nothing."),
            UseFieldColors = new GUIContent("Use Field Colors",
                "If enabled, the X/Y/Z fields will be colored Red/Green/Blue respectively."),
            EmphasizeNonDefaultFields = new GUIContent("Emphasize Non-Default Fields",
                "If enabled, Transform fields which aren't at their default value will be given a thicker border."),
            ItaliciseNonSnappedFields = new GUIContent("Italicise Non-Snapped Fields",
                "If enabled, Transform fields which aren't a multiple of the snap increment specified in Edit/Snap Setings will use italic text."),
            DefaultToUniformScale = new GUIContent("Default to Uniform Scale",
                "If enabled, Transform scale will be shown as a single float field by default when the selected object has the same scale on all axes."),
            SnapToGroundDistance = new GUIContent("Snap to Ground Distance",
                "The distance within which to check for the ground when using the Snap to Ground function in the Transform Position context menu."),
            //SnapToGroundLayers = new GUIContent("Snap to Ground Layers", "This layer mask determines which physics layers are treated as ground for the Transform Position context menu.");

            // Scene Tools.
            OverrideTransformGizmos = new GUIContent("Override Transform Gizmos",
                "If enabled, the default scene gizmos will be overwritten in order to implement various features like \"Freeze child transforms\" and \"Draw gizmos for all selected objects\"."),
            ShowMovementGuides = new GUIContent("Show Movement Guides",
                "If enabled, the scene view movement tool will show some extra lines while you are moving an object to indicate where you are moving it from."),
            ShowMovementDistance = new GUIContent("Show Movement Distance",
                "If enabled, moving an object will display the distance from the old position."),
            ShowPositionLabels = new GUIContent("Show Position Labels",
                "If enabled, the scene view will show the selected object's position around the Move tool."),

            // Script Inspector.
            HideScriptProperty = new GUIContent("Hide Script Property",
                "If enabled, the \"Script\" property at the top of each MonoBehaviour inspector will be hidden to save space."),
            ObjectEditorNestLimit = new GUIContent("Object Editor Nest Limit",
                "If higher than 0, Object fields will be drawn with a foldout arrow to draw the target object's inspector nested inside the current one.");

#if !UNITY_5_6_OR_LATER
        private static Vector2 _ScrollPosition;
#endif

        /************************************************************************************************************************/

        [PreferenceItem("Inspector\nGadgets")]
        private static void DrawPreferences()
        {
#if !UNITY_5_6_OR_LATER
            _ScrollPosition = GUILayout.BeginScrollView(_ScrollPosition);
#endif

            // Version.
            GUILayout.BeginHorizontal();
            {
#if PRO

                GUILayout.Label("Inspector Gadgets Pro v" + InspectorGadgetsUtils.InspectorGadgetsVersion, GUILayout.Width(EditorGUIUtility.labelWidth - 4));

#else

                GUILayout.Label("Inspector Gadgets Lite v" + InspectorGadgetsUtils.InspectorGadgetsVersion);

                if (GUILayout.Button("Purchase Inspector Gadgets Pro"))
                    InspectorGadgetsUtils.OpenInspectorGadgetsProInAssetStore();

#endif

                if (GUILayout.Button("Open Manual"))
                    InspectorGadgetsUtils.OpenManual();
            }
            GUILayout.EndHorizontal();

#if LITE
            GUI.enabled = false;
#endif

            EditorGUILayout.Space();
            GUILayout.Label("Transform Inspector", EditorStyles.boldLabel);
            TransformPropertyDrawer.ShowCopyButton.DrawToggle(ShowCopyButton);
            TransformPropertyDrawer.ShowPasteButton.DrawToggle(ShowPasteButton);
            TransformPropertyDrawer.ShowSnapButton.DrawToggle(ShowSnapButton);
            TransformPropertyDrawer.ShowResetButton.DrawToggle(ShowResetButton);
            TransformPropertyDrawer.DisableUselessButtons.DrawToggle(DisableUselessButtons);
            TransformPropertyDrawer.UseFieldColors.DrawToggle(UseFieldColors);
            TransformPropertyDrawer.EmphasizeNonDefaultFields.DrawToggle(EmphasizeNonDefaultFields);
            TransformPropertyDrawer.ItaliciseNonSnappedFields.DrawToggle(ItaliciseNonSnappedFields);
            TransformEditor.DefaultToUniformScale.DrawToggle(DefaultToUniformScale);
#if UNITY_5_6_OR_LATER
            if (PositionDrawer.SnapToGroundDistance.DrawField(SnapToGroundDistance))
                PositionDrawer.SnapToGroundDistance.Value = Mathf.Max(PositionDrawer.SnapToGroundDistance, 0);
#endif

            EditorGUILayout.Space();
            GUILayout.Label("Scene Tools", EditorStyles.boldLabel);
            TransformEditor.OverrideTransformGizmos.DrawToggle(OverrideTransformGizmos);
            if (!TransformEditor.OverrideTransformGizmos)
            {
                EditorGUILayout.HelpBox("With this disabled, features like \"Freeze child transforms\" and \"Draw gizmos for all selected objects\" won't work.", MessageType.Warning);
                Tools.hidden = false;
                GUI.enabled = false;
            }
            PositionDrawer.ShowMovementGuides.DrawToggle(ShowMovementGuides);
            PositionDrawer.ShowMovementDistance.DrawToggle(ShowMovementDistance);
            PositionDrawer.ShowPositionLabels.DrawToggle(ShowPositionLabels);
            GUI.enabled = true;
            AutoHideUI.DrawEnabledToggle();

#if PRO
            EditorGUILayout.Space();
            GUILayout.Label("Script Inspector", EditorStyles.boldLabel);
            ComponentEditor.HideScriptProperty.DrawToggle(HideScriptProperty);

            EditorGUI.BeginChangeCheck();
            int value = EditorGUILayout.IntSlider(ObjectEditorNestLimit, ObjectDrawer.ObjectEditorNestLimit.Value, 0, 10);
            if (EditorGUI.EndChangeCheck())
                ObjectDrawer.ObjectEditorNestLimit.Value = value;
#endif

#if LITE
            GUI.enabled = true;// Still let the scroll bar catch scroll wheel events.
#endif

#if !UNITY_5_6_OR_LATER
            GUILayout.EndScrollView();
#endif
        }

        /************************************************************************************************************************/
    }
}

#endif