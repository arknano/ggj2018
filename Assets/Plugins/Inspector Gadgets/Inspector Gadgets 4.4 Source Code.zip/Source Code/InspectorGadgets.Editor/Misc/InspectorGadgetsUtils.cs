// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>
    /// Various utility methods used by <see cref="InspectorGadgets"/>.
    /// </summary>
    public static partial class InspectorGadgetsUtils
    {
        /************************************************************************************************************************/

        /// <summary>This is Inspector Gadgets v4.4.</summary>
        public static readonly string InspectorGadgetsVersion = "4.4";

#if PRO// Inspector Gadgets Pro.
        internal const bool IsInspectorGadgetsPro = true;
#else// Inspector Gadgets Lite.
        internal const bool IsInspectorGadgetsPro = false;

#if UNITY_EDITOR && LITE
        [UnityEditor.MenuItem("CONTEXT/Transform/Purchase Inspector Gadgets Pro")]
        internal static void OpenInspectorGadgetsProInAssetStore()
        {
            UnityEditorInternal.AssetStore.Open("content/83013");
        }
#endif
#endif

        /************************************************************************************************************************/
        #region Strings
        /************************************************************************************************************************/

        /// <summary>
        /// Adds spaces to 'camelCase' before each uppercase letter.
        /// </summary>
        public static string ConvertCamelCaseToFriendly(string camelCase, bool uppercaseFirst = false)
        {
            StringBuilder friendly = new StringBuilder();
            ConvertCamelCaseToFriendly(friendly, camelCase, 0, camelCase.Length, uppercaseFirst);
            return friendly.ToString();
        }

        /// <summary>
        /// Adds spaces to 'camelCase' before each uppercase letter.
        /// </summary>
        public static void ConvertCamelCaseToFriendly(StringBuilder friendly, string camelCase, int start, int end, bool uppercaseFirst = false)
        {
            friendly.Append(uppercaseFirst ?
                char.ToUpper(camelCase[start]) :
                camelCase[start]);

            start++;

            for (; start < end; start++)
            {
                char character = camelCase[start];
                if (char.IsUpper(character))// Space before upper case.
                {
                    friendly.Append(' ');
                    friendly.Append(character);

                    // No spaces between consecutive upper case, unless followed by a non-upper case.
                    start++;
                    if (start >= camelCase.Length) return;
                    else
                    {
                        character = camelCase[start];
                        if (!char.IsUpper(character))
                        {
                            start--;
                        }
                        else
                        {
                            char nextCharacter;
                            while (true)
                            {
                                start++;
                                if (start >= camelCase.Length)
                                {
                                    friendly.Append(character);
                                    return;
                                }
                                else
                                {
                                    nextCharacter = camelCase[start];

                                    if (char.IsUpper(nextCharacter))
                                    {
                                        friendly.Append(character);
                                    }
                                    else
                                    {
                                        friendly.Append(' ');
                                        friendly.Append(character);
                                        friendly.Append(nextCharacter);
                                        break;
                                    }

                                    character = nextCharacter;
                                }
                            }
                        }
                    }
                }
                else if (char.IsNumber(character))// Space before number.
                {
                    friendly.Append(' ');
                    friendly.Append(character);
                    while (true)
                    {
                        start++;
                        if (start >= camelCase.Length) return;
                        else
                        {
                            character = camelCase[start];

                            if (char.IsNumber(character))
                                friendly.Append(character);
                            else
                            {
                                start--;
                                break;
                            }
                        }
                    }
                }
                else friendly.Append(character);// Otherwise just append the character.
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Adds spaces to 'fieldName' before each uppercase letter and removes any underscores from the start.
        /// </summary>
        public static string ConvertFieldNameToFriendly(string fieldName, bool uppercaseFirst = false)
        {
            if (string.IsNullOrEmpty(fieldName))
                return "";

            StringBuilder friendly = new StringBuilder();

            int start = 0;
            while (fieldName[start] == '_')
            {
                start++;
                if (start >= fieldName.Length)
                    return fieldName;
            }

            ConvertCamelCaseToFriendly(friendly, fieldName, start, fieldName.Length, uppercaseFirst);
            return friendly.ToString();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Truncate the given string so it can be used in a GUI.Label. MaxLength = 16,382.
        /// </summary>
        public static string TruncateForLabel(string text)
        {
            const int MaxLength = 16382;// 16384 is a power of 2.
            if (text.Length > MaxLength)
                return text.Substring(0, MaxLength);
            else
                return text;
        }

        /************************************************************************************************************************/

        /// <summary>Returns a string containing the value of each element in 'collection'.</summary>
        public static string DeepToString(this IEnumerable collection, string separator)
        {
            if (collection == null)
                return "null";
            else
                return collection.GetEnumerator().DeepToString(separator);
        }

        /// <summary>Returns a string containing the value of each element in 'collection' (each on a new line).</summary>
        public static string DeepToString(this IEnumerable collection)
        {
            return collection.DeepToString(Environment.NewLine);
        }

        /************************************************************************************************************************/

        /// <summary>Each element returned by 'enumerator' is appended to 'text'.</summary>
        public static void AppendDeepToString(StringBuilder text, IEnumerator enumerator, string separator)
        {
            text.Append("[]");
            int countIndex = text.Length - 1;
            int count = 0;

            while (enumerator.MoveNext())
            {
                text.Append(separator);
                text.Append('[');
                text.Append(count);
                text.Append("] = ");
                text.Append(enumerator.Current);

                count++;
            }

            text.Insert(countIndex, count);
        }

        /// <summary>Returns a string containing the value of each element in 'enumerator'.</summary>
        public static string DeepToString(this IEnumerator enumerator, string separator)
        {
            StringBuilder text = new StringBuilder();
            AppendDeepToString(text, enumerator, separator);
            return text.ToString();
        }

        /// <summary>Returns a string containing the value of each element in 'enumerator' (each on a new line).</summary>
        public static string DeepToString(this IEnumerator enumerator)
        {
            return enumerator.DeepToString(Environment.NewLine);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the full transform path to the target with slashes between the names of each of its parents, much like a file path.
        /// </summary>
        public static void AppendTransformPath(StringBuilder text, Transform target)
        {
            if (target.parent != null)
            {
                AppendTransformPath(text, target.parent);
                text.Append('/');
            }

            text.Append(target.name);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If 'source' isn't null, 'target' is given its value.
        /// </summary>
        public static void Set(this float? source, ref float target)
        {
            if (source != null)
                target = source.Value;
        }

        /// <summary>
        /// If 'source' isn't null, return its value, otherwise return 'target'.
        /// </summary>
        public static float Set(this float? source, float target)
        {
            return source != null ? source.Value : target;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns the specified 'value' as a string, or "-" if it is null.
        /// </summary>
        public static string ToDisplayString(this float? value)
        {
            return value != null ? value.Value.ToString(CultureInfo.InvariantCulture) : "-";
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Type Names
        /************************************************************************************************************************/

        private static readonly Dictionary<Type, string>
            TypeNames = new Dictionary<Type, string>
            {
                { typeof(object), "object" },
                { typeof(void), "void" },
                { typeof(bool), "bool" },
                { typeof(byte), "byte" },
                { typeof(sbyte), "sbyte" },
                { typeof(char), "char" },
                { typeof(string), "string" },
                { typeof(short), "short" },
                { typeof(int), "int" },
                { typeof(long), "long" },
                { typeof(ushort), "ushort" },
                { typeof(uint), "uint" },
                { typeof(ulong), "ulong" },
                { typeof(float), "float" },
                { typeof(double), "double" },
                { typeof(decimal), "decimal" },
            };

        private static readonly Dictionary<Type, string>
            FullTypeNames = new Dictionary<Type, string>(TypeNames);

        /************************************************************************************************************************/

        /// <summary>
        /// Returns the name of a 'type' as it would appear in C# code.
        /// <para></para>
        /// For example, typeof(List&lt;float&gt;).FullName would give you:
        /// System.Collections.Generic.List`1[[System.Single, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
        /// <para></para>
        /// This method would instead return System.Collections.Generic.List&lt;float&gt; if 'fullName' is true, or
        /// just List&lt;float&gt; if it is false.
        /// <para></para>
        /// Note that all returned values are stored in a dictionary to speed up repeated use.
        /// </summary>
        public static string GetNameCS(this Type type, bool fullName = true)
        {
            if (type == null)
                return "";

            // Check if we have already got the name for that type.
            var names = fullName ? FullTypeNames : TypeNames;
            if (names.TryGetValue(type, out string name))
                return name;

            StringBuilder text = new StringBuilder();

            if (type.IsArray)// Array = TypeName[].
            {
                text.Append(type.GetElementType().GetNameCS(fullName));

                text.Append('[');
                int dimensions = type.GetArrayRank();
                while (dimensions-- > 1)
                    text.Append(",");
                text.Append(']');

                goto Return;
            }

            if (type.IsPointer)// Pointer = TypeName*.
            {
                text.Append(type.GetElementType().GetNameCS(fullName));
                text.Append('*');

                goto Return;
            }

            if (type.IsGenericParameter)// Generic Parameter = TypeName (for unspecified generic parameters).
            {
                text.Append(type.Name);
                goto Return;
            }

            Type underlyingType = Nullable.GetUnderlyingType(type);
            if (underlyingType != null)// Nullable = TypeName?.
            {
                text.Append(underlyingType.GetNameCS(fullName));
                text.Append('?');

                goto Return;
            }

            // Other Type = Namespace.NestedTypes.TypeName<GenericArguments>.

            if (fullName && type.Namespace != null)// Namespace.
            {
                text.Append(type.Namespace);
                text.Append('.');
            }

            int genericArguments = 0;

            if (type.DeclaringType != null)// Account for Nested Types.
            {
                // Count the nesting level.
                int nesting = 1;
                Type declaringType = type.DeclaringType;
                while (declaringType.DeclaringType != null)
                {
                    declaringType = declaringType.DeclaringType;
                    nesting++;
                }

                // Append the name of each outer type, starting from the outside.
                while (nesting-- > 0)
                {
                    // Walk out to the current nesting level.
                    // This avoids the need to make a list of types in the nest or to insert type names instead of appending them.
                    declaringType = type;
                    for (int i = nesting; i >= 0; i--)
                        declaringType = declaringType.DeclaringType;

                    // Nested Type Name.
                    genericArguments = AppendNameAndGenericArguments(text, declaringType, fullName, genericArguments);
                    text.Append('.');
                }
            }

            // Type Name.
            genericArguments = AppendNameAndGenericArguments(text, type, fullName, genericArguments);

            Return:// Remember and return the name.
            name = text.ToString();
            names.Add(type, name);
            return name;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the generic arguments of 'type' (after skipping the specified number).
        /// </summary>
        public static int AppendNameAndGenericArguments(StringBuilder text, Type type, bool fullName = true, int skipGenericArguments = 0)
        {
            text.Append(type.Name);

            if (type.IsGenericType)
            {
                int backQuote = type.Name.IndexOf('`');
                if (backQuote >= 0)
                {
                    text.Length -= type.Name.Length - backQuote;

                    Type[] genericArguments = type.GetGenericArguments();
                    if (skipGenericArguments < genericArguments.Length)
                    {
                        text.Append('<');

                        Type firstArgument = genericArguments[skipGenericArguments];
                        skipGenericArguments++;

                        if (firstArgument.IsGenericParameter)
                        {
                            while (skipGenericArguments < genericArguments.Length)
                            {
                                text.Append(',');
                                skipGenericArguments++;
                            }
                        }
                        else
                        {
                            text.Append(firstArgument.GetNameCS(fullName));

                            while (skipGenericArguments < genericArguments.Length)
                            {
                                text.Append(", ");
                                text.Append(genericArguments[skipGenericArguments].GetNameCS(fullName));
                                skipGenericArguments++;
                            }
                        }

                        text.Append('>');
                    }
                }
            }

            return skipGenericArguments;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Member Names
        /************************************************************************************************************************/

        /// <summary>
        /// Returns the full name of a 'member' as it would appear in C# code.
        /// <para></para>
        /// For example, passing this method info in as its own parameter would return "<see cref="InspectorGadgetsUtils"/>.GetNameCS".
        /// <para></para>
        /// Note that when 'member' is a <see cref="Type"/>, this method calls <see cref="GetNameCS(Type, bool)"/> instead.
        /// </summary>
        public static string GetNameCS(this MemberInfo member, bool fullName = true)
        {
            if (member == null)
                return "null";

            if (member is Type type)
                return type.GetNameCS(fullName);

            StringBuilder text = new StringBuilder();

            if (member.DeclaringType != null)
            {
                text.Append(member.DeclaringType.GetNameCS(fullName));
                text.Append('.');
            }

            text.Append(member.Name);

            return text.ToString();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the full name of a 'member' as it would appear in C# code.
        /// <para></para>
        /// For example, passing this method info in as its own parameter would append "<see cref="InspectorGadgetsUtils"/>.AppendName".
        /// <para></para>
        /// Note that when 'member' is a <see cref="Type"/>, this method calls <see cref="GetNameCS(Type, bool)"/> instead.
        /// </summary>
        public static StringBuilder AppendNameCS(this StringBuilder text, MemberInfo member, bool fullName = true)
        {
            if (member == null)
            {
                text.Append("null");
                return text;
            }

            if (member is Type type)
            {
                text.Append(type.GetNameCS(fullName));
                return text;
            }

            if (member.DeclaringType != null)
            {
                text.Append(member.DeclaringType.GetNameCS(fullName));
                text.Append('.');
            }

            text.Append(member.Name);

            return text;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Attributes
        /************************************************************************************************************************/

        /// <summary>
        /// Gets a single custom attribute of type T and casts it.
        /// </summary>
        public static T GetCustomAttribute<T>(this ICustomAttributeProvider target, bool inherit = false) where T : Attribute
        {
            Type attributeType = typeof(T);
            if (!target.IsDefined(attributeType, inherit))
                return null;
            else
                return (T)target.GetCustomAttributes(attributeType, inherit)[0];
        }

        /************************************************************************************************************************/

        /// <summary>Get all fields with the specified attribute in 'type'.</summary>
        public static void GetAttributedFields<TAttribute>(Type type, BindingFlags bindingFlags, List<TAttribute> attributes, List<FieldInfo> fields)
            where TAttribute : Attribute
        {
            Type attributeType = typeof(TAttribute);

            FieldInfo[] allFields = type.GetFields(bindingFlags);

            for (int iField = 0; iField < allFields.Length; iField++)
            {
                FieldInfo field = allFields[iField];
                if (!field.IsDefined(attributeType, true))
                    continue;

                object[] methodAttributes = field.GetCustomAttributes(attributeType, true);
                for (int iAttribute = 0; iAttribute < methodAttributes.Length; iAttribute++)
                {
                    attributes.Add((TAttribute)methodAttributes[iAttribute]);
                    fields.Add(field);
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>Get all properties with the specified attribute in 'type'.</summary>
        public static void GetAttributedProperties<TAttribute>(Type type, BindingFlags bindingFlags, List<TAttribute> attributes, List<PropertyInfo> properties)
            where TAttribute : Attribute
        {
            Type attributeType = typeof(TAttribute);

            PropertyInfo[] allProperties = type.GetProperties(bindingFlags);

            for (int iProperty = 0; iProperty < allProperties.Length; iProperty++)
            {
                PropertyInfo property = allProperties[iProperty];
                if (!property.IsDefined(attributeType, true))
                    continue;

                object[] methodAttributes = property.GetCustomAttributes(attributeType, true);
                for (int iAttribute = 0; iAttribute < methodAttributes.Length; iAttribute++)
                {
                    attributes.Add((TAttribute)methodAttributes[iAttribute]);
                    properties.Add(property);
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>Get all methods with the specified attribute in 'type'.</summary>
        public static void GetAttributedMethods<TAttribute>(Type type, BindingFlags bindingFlags, List<TAttribute> attributes, List<MethodInfo> methods)
            where TAttribute : Attribute
        {
            Type attributeType = typeof(TAttribute);

            MethodInfo[] allMethods = type.GetMethods(bindingFlags);

            for (int iMethod = 0; iMethod < allMethods.Length; iMethod++)
            {
                MethodInfo method = allMethods[iMethod];

                if (!method.IsDefined(attributeType, true))
                    continue;

                object[] methodAttributes = method.GetCustomAttributes(attributeType, true);
                for (int iAttribute = 0; iAttribute < methodAttributes.Length; iAttribute++)
                {
                    attributes.Add((TAttribute)methodAttributes[iAttribute]);
                    methods.Add(method);
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Calls the specified 'method' once for each type in each loaded assembly that references the specified 'assembly'.
        /// </summary>
        public static void ForEachTypeInDependantAssemblies(Assembly assembly, Action<Type> method)
        {
            ForEachType(assembly, method);

            string name = assembly.GetName().Name;

            var assemblies = AppDomain.CurrentDomain.GetAssemblies();
            for (int i = 0; i < assemblies.Length; i++)
            {
                var otherAssembly = assemblies[i];
                if (otherAssembly == assembly)
                    goto NextAssembly;

                var references = otherAssembly.GetReferencedAssemblies();
                for (int j = 0; j < references.Length; j++)
                {
                    if (references[j].Name == name)
                    {
                        ForEachType(otherAssembly, method);
                        goto NextAssembly;
                    }
                }

                NextAssembly: continue;
            }
        }

        /// <summary>
        /// Calls the specified 'method' once for each type in the specified 'assembly'.
        /// </summary>
        public static void ForEachType(Assembly assembly, Action<Type> method)
        {
            var types = assembly.GetTypes();
            for (int i = 0; i < types.Length; i++)
                method(types[i]);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Tries various search methods until it finds something: first GetComponent, then GetComponentInParent,
        /// then GetComponentInChildren, then FindObjectOfType.
        /// </summary>
        public static Component ProgressiveSearch(GameObject gameObject, Type componentType)
        {
            Component component;

            component = gameObject.GetComponent(componentType);
            if (component != null)
                return component;

            component = gameObject.GetComponentInParent(componentType);
            if (component != null)
                return component;

            component = gameObject.GetComponentInChildren(componentType);
            if (component != null)
                return component;

            component = UnityEngine.Object.FindObjectOfType(componentType) as Component;
            if (component != null)
                return component;

            return null;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Tries various search methods until it finds something: first GetComponent, then GetComponentInParent,
        /// then GetComponentInChildren, then FindObjectOfType.
        /// </summary>
        public static T ProgressiveSearch<T>(GameObject gameObject, Type componentType) where T : Component
        {
            T component;

            component = gameObject.GetComponent<T>();
            if (component != null)
                return component;

            component = gameObject.GetComponentInParent<T>();
            if (component != null)
                return component;

            component = gameObject.GetComponentInChildren<T>();
            if (component != null)
                return component;

            component = UnityEngine.Object.FindObjectOfType<T>();
            if (component != null)
                return component;

            return null;
        }

        /************************************************************************************************************************/
    }
}